export default function AboutUs() {
  return (
    <div className="mx-auto max-w-5xl space-y-8">
      <header className="space-y-2">
        <h1 className="text-4xl font-extrabold tracking-tight">About BloodBank</h1>
        <p className="text-muted-foreground max-w-2xl">We connect donors, blood centres and volunteers on a single platform to ensure timely, transparent and safe blood availability. Our mission is simple: save lives by making blood donation efficient, reliable and accessible.</p>
      </header>

      <section className="grid gap-6 md:grid-cols-3">
        <div className="rounded-lg border p-5">
          <h3 className="font-semibold">Our Mission</h3>
          <p className="text-sm text-muted-foreground mt-2">Enable real-time availability, streamline donations and empower communities to respond fast during emergencies.</p>
        </div>
        <div className="rounded-lg border p-5">
          <h3 className="font-semibold">Our Vision</h3>
          <p className="text-sm text-muted-foreground mt-2">A world where every hospital has timely access to the blood types they need and donors can help with minimal friction.</p>
        </div>
        <div className="rounded-lg border p-5">
          <h3 className="font-semibold">Community</h3>
          <p className="text-sm text-muted-foreground mt-2">We partner with certified blood centres, hospitals and local organisations to maintain safety and quality.</p>
        </div>
      </section>

      <section>
        <h2 className="text-2xl font-bold">Our Services</h2>
        <div className="mt-4 grid gap-4 sm:grid-cols-2">
          <ServiceCard title="Live Stock Tracking" desc="Monitor blood units across centres in real-time with low-stock alerts and thresholds." />
          <ServiceCard title="Donor Directory" desc="Search and connect with pre-screened donors based on blood group and location." />
          <ServiceCard title="Donation Camps" desc="Create, manage and discover upcoming donation drives in your city." />
          <ServiceCard title="Volunteer Management" desc="Register volunteers, assign roles and coordinate outreach campaigns." />
        </div>
      </section>

      <section>
        <h2 className="text-2xl font-bold">Key Features</h2>
        <ul className="mt-4 grid gap-3 md:grid-cols-3">
          <li className="rounded-md border p-4">
            <div className="font-semibold">Real-time Alerts</div>
            <div className="text-sm text-muted-foreground">Automatic notifications when any blood group falls below the safety threshold.</div>
          </li>
          <li className="rounded-md border p-4">
            <div className="font-semibold">Intuitive Dashboard</div>
            <div className="text-sm text-muted-foreground">Overview of total units, donors, centres and upcoming camps at a glance.</div>
          </li>
          <li className="rounded-md border p-4">
            <div className="font-semibold">Location Maps</div>
            <div className="text-sm text-muted-foreground">Visualize centres and camps on the map to find the nearest resources.</div>
          </li>
          <li className="rounded-md border p-4">
            <div className="font-semibold">Secure Data"</div>
            <div className="text-sm text-muted-foreground">Built with best practices to protect donor and centre information.</div>
          </li>
          <li className="rounded-md border p-4">
            <div className="font-semibold">Easy Registration</div>
            <div className="text-sm text-muted-foreground">Simple forms for donors and volunteers to get involved quickly.</div>
          </li>
          <li className="rounded-md border p-4">
            <div className="font-semibold">Reports & Insights</div>
            <div className="text-sm text-muted-foreground">Analytics to help centres manage inventory and plan drives.</div>
          </li>
        </ul>
      </section>

      <section>
        <h2 className="text-2xl font-bold">How It Works</h2>
        <ol className="mt-4 space-y-4 list-decimal pl-5 text-sm text-muted-foreground">
          <li>
            <strong>Centres update stock</strong>: Partner centres update their blood unit availability manually or via integrations.
          </li>
          <li>
            <strong>System monitors levels</strong>: The platform continuously checks inventory and triggers alerts when stock is low.
          </li>
          <li>
            <strong>Donors get notified</strong>: Matching donors in the area receive notification prompts to donate.
          </li>
          <li>
            <strong>Camps & volunteers</strong>: Organisers create donation camps and volunteers coordinate outreach for turnout.
          </li>
          <li>
            <strong>Delivery & follow-up</strong>: Centres confirm receipt of blood and the platform tracks donations and outcomes.
          </li>
        </ol>
      </section>

      <section className="rounded-lg border p-6">
        <h3 className="text-xl font-semibold">Get Involved</h3>
        <p className="text-sm text-muted-foreground mt-2">Whether you are a donor, a volunteer, or a clinic partner — register with us to receive alerts and help save lives.</p>
        <div className="mt-4 flex gap-3">
          <a href="/donor-register" className="rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground">Register as Donor</a>
          <a href="/register" className="rounded-md border px-4 py-2 text-sm font-medium">Join as Volunteer</a>
        </div>
      </section>
    </div>
  );
}

function ServiceCard({ title, desc }: { title: string; desc: string }) {
  return (
    <div className="rounded-md border p-4">
      <div className="font-semibold">{title}</div>
      <div className="text-sm text-muted-foreground mt-1">{desc}</div>
    </div>
  );
}
