import React from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { adminGetDonors, adminApproveDonor, adminRejectDonor, adminGetVolunteers, adminDeleteVolunteer, adminNotifyDonor, adminGetCentres, adminApproveCentre, adminRejectCentre, adminGetCamps, adminApproveCamp, adminRejectCamp } from '@/lib/api';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { useNavigate } from 'react-router-dom';
import { LogOut } from 'lucide-react';

export default function AdminDashboard() {
  const qc = useQueryClient();
  const navigate = useNavigate();
  const [isAuthenticated, setIsAuthenticated] = React.useState(false);
  const [expandedDonorId, setExpandedDonorId] = React.useState<string | null>(null);

  // redirect to login if no token
  React.useEffect(() => {
    const token = typeof window !== 'undefined' ? localStorage.getItem('bb_admin_token') : null;
    if (!token) {
      navigate('/admin/login');
    } else {
      setIsAuthenticated(true);
    }
  }, [navigate]);

  const handleLogout = () => {
    localStorage.removeItem('bb_admin_token');
    localStorage.removeItem('bb_admin');
    setIsAuthenticated(false);
    navigate('/admin/login');
  };

  const { data: donors, isLoading: loadingDonors } = useQuery({ queryKey: ['admin', 'donors'], queryFn: adminGetDonors, enabled: isAuthenticated });
  const { data: volunteers, isLoading: loadingVolunteers, refetch: refetchVolunteers } = useQuery({ queryKey: ['admin', 'volunteers'], queryFn: () => adminGetVolunteers(), refetchInterval: 5000, enabled: isAuthenticated });
  const { data: centres, isLoading: loadingCentres } = useQuery({ queryKey: ['admin', 'centres'], queryFn: adminGetCentres, enabled: isAuthenticated });
  const { data: camps, isLoading: loadingCamps } = useQuery({ queryKey: ['admin', 'camps'], queryFn: adminGetCamps, enabled: isAuthenticated });


  // Listen for volunteer registrations from other tabs/windows and refresh
  React.useEffect(() => {
    function onStorage(e: StorageEvent) {
      if (e.key === 'bb_volunteer_updated') {
        refetchVolunteers();
      }
    }
    function onCustom() {
      refetchVolunteers();
    }
    window.addEventListener('storage', onStorage);
    window.addEventListener('bb_volunteer_updated', onCustom as EventListener);
    return () => {
      window.removeEventListener('storage', onStorage);
      window.removeEventListener('bb_volunteer_updated', onCustom as EventListener);
    };
  }, [refetchVolunteers]);

  const approveDonorMut = useMutation({ mutationFn: (id: string) => adminApproveDonor(id), onSuccess: () => qc.invalidateQueries({ queryKey: ['admin', 'donors'] }) });
  const rejectDonorMut = useMutation({ mutationFn: (id: string) => adminRejectDonor(id), onSuccess: () => qc.invalidateQueries({ queryKey: ['admin', 'donors'] }) });
  const notifyDonorMut = useMutation({ mutationFn: ({ id, payload }: { id: string; payload: { method: 'sms' | 'email'; message: string } }) => adminNotifyDonor(id, payload), onSuccess: () => qc.invalidateQueries({ queryKey: ['admin', 'donors'] }) });

  const deleteVolunteerMut = useMutation({ mutationFn: (id: string) => adminDeleteVolunteer(id), onSuccess: () => qc.invalidateQueries({ queryKey: ['admin', 'volunteers'] }) });

  const approveCentreMut = useMutation({ mutationFn: (id: string) => adminApproveCentre(id), onSuccess: () => qc.invalidateQueries({ queryKey: ['admin', 'centres'] }) });
  const rejectCentreMut = useMutation({ mutationFn: (id: string) => adminRejectCentre(id), onSuccess: () => qc.invalidateQueries({ queryKey: ['admin', 'centres'] }) });

  const approveCampMut = useMutation({ mutationFn: (id: string) => adminApproveCamp(id), onSuccess: () => qc.invalidateQueries({ queryKey: ['admin', 'camps'] }) });
  const rejectCampMut = useMutation({ mutationFn: (id: string) => adminRejectCamp(id), onSuccess: () => qc.invalidateQueries({ queryKey: ['admin', 'camps'] }) });

  const [debug, setDebug] = React.useState<any | null>(null);
  // derive displayed volunteers and dedupe by id/email/name to avoid duplicate keys
  const displayedVolunteers = React.useMemo(() => {
    const src = (volunteers && volunteers.length > 0) ? volunteers : (debug?.memoryPreview || []);
    const seen = new Set<string>();
    const out: any[] = [];
    for (const v of (src || [])) {
      const key = String(v._id ?? v.email ?? v.name ?? JSON.stringify(v));
      if (seen.has(key)) continue;
      seen.add(key);
      out.push(v);
    }
    return out;
  }, [volunteers, debug]);

  async function fetchDebug() {
    try {
      const token = typeof window !== 'undefined' ? localStorage.getItem('bb_admin_token') : null;
      const headers: Record<string,string> = {};
      if (token) headers['Authorization'] = `Bearer ${token}`;

      const [pubRes, adminRes] = await Promise.all([
        fetch('/api/debug/memory-volunteers'),
        fetch('/api/debug/volunteers', { headers }),
      ]);

      const pubJson = await pubRes.json().catch(() => ({}));
      let adminJson = null;
      if (adminRes.ok) adminJson = await adminRes.json().catch(() => null);
      else adminJson = { error: `admin endpoint returned ${adminRes.status} ${adminRes.statusText}` };

      setDebug({ memory: pubJson, admin: adminJson, dbConnected: adminJson?.dbConnected ?? false, dbCount: adminJson?.dbCount ?? 0, memoryCount: pubJson?.memoryCount ?? 0, memoryPreview: pubJson?.memoryPreview ?? [] , dbPreview: adminJson?.dbPreview ?? [] });
    } catch (e: any) {
      setDebug({ error: e?.message || String(e) });
    }
  }

  // Auto-fetch debug info on mount
  React.useEffect(() => {
    fetchDebug();
    // also refetch volunteers once to ensure displayedVolunteers picks up any memoryPreview
    try { refetchVolunteers(); } catch (e) { /* ignore */ }
  }, []);

  return (
    <div className="mx-auto max-w-7xl">
      <div className="flex items-center justify-between mb-4">
        <h1 className="text-2xl font-bold">Admin Dashboard</h1>
        <div className="flex gap-2">
          <Button onClick={() => navigate('/admin/emergency-alert')} className="bg-red-700 text-white hover:bg-red-800">
            Send Emergency Alert
          </Button>
          <Button onClick={handleLogout} className="bg-gray-600 text-white hover:bg-gray-700 flex items-center gap-2">
            <LogOut className="h-4 w-4" />
            Logout
          </Button>
        </div>
      </div>

      <section className="mb-6">
        <Card>
          <CardHeader>
            <CardTitle>Donor Registrations</CardTitle>
          </CardHeader>
          <CardContent>
            {loadingDonors ? (
              <div>Loading donors...</div>
            ) : (
              <div className="space-y-2">
                {(donors ?? []).length === 0 ? (
                  <div className="text-sm text-muted-foreground p-4">No donors found</div>
                ) : (
                  (donors ?? []).map((d: any) => {
                    const donorId = d._id ?? d.email ?? d.name;
                    const isExpanded = expandedDonorId === donorId;
                    return (
                      <div key={donorId} className="border rounded-lg overflow-hidden">
                        <button
                          onClick={() => setExpandedDonorId(isExpanded ? null : donorId)}
                          className="w-full flex items-center justify-between p-4 hover:bg-gray-50 transition-colors"
                        >
                          <div className="flex items-center gap-4 flex-1 text-left">
                            <span className="text-lg">{isExpanded ? '▼' : '▶'}</span>
                            <div>
                              <div className="font-semibold">{d.name}</div>
                              <div className="text-sm text-gray-600">{d.email}</div>
                            </div>
                          </div>
                          <div className="flex gap-2 items-center">
                            <span className="text-sm font-medium">{d.bloodGroup}</span>
                            <span className="text-sm">{String(d.approved ?? false)}</span>
                          </div>
                        </button>

                        {isExpanded && (
                          <div className="bg-gray-50 border-t p-4 space-y-3 text-sm">
                            <div className="grid grid-cols-2 gap-4">
                              <div>
                                <span className="font-semibold">Name:</span> {d.name}
                              </div>
                              <div>
                                <span className="font-semibold">Email:</span> {d.email}
                              </div>
                              <div>
                                <span className="font-semibold">Blood Group:</span> {d.bloodGroup}
                              </div>
                              <div>
                                <span className="font-semibold">Approved:</span> {String(d.approved ?? false)}
                              </div>
                              {d.phone && (
                                <div>
                                  <span className="font-semibold">Phone:</span> {d.phone}
                                </div>
                              )}
                              {d.age && (
                                <div>
                                  <span className="font-semibold">Age:</span> {d.age}
                                </div>
                              )}
                              {d.city && (
                                <div>
                                  <span className="font-semibold">City:</span> {d.city}
                                </div>
                              )}
                              {d.address && (
                                <div>
                                  <span className="font-semibold">Address:</span> {d.address}
                                </div>
                              )}
                              {d.gender && (
                                <div>
                                  <span className="font-semibold">Gender:</span> {d.gender}
                                </div>
                              )}
                              {d.dob && (
                                <div>
                                  <span className="font-semibold">Date of Birth:</span> {new Date(d.dob).toLocaleDateString()}
                                </div>
                              )}
                              {d.lastDonationDate && (
                                <div>
                                  <span className="font-semibold">Last Donation:</span> {new Date(d.lastDonationDate).toLocaleDateString()}
                                </div>
                              )}
                              {d.hemoglobin && (
                                <div>
                                  <span className="font-semibold">Hemoglobin:</span> {d.hemoglobin} g/dL
                                </div>
                              )}
                              {d.diseases && (
                                <div className="col-span-2">
                                  <span className="font-semibold">Medical Conditions:</span> {d.diseases}
                                </div>
                              )}
                            </div>
                            <div className="flex gap-2 flex-wrap pt-4 border-t">
                              <Button onClick={() => approveDonorMut.mutate(donorId)} disabled={approveDonorMut.isLoading} size="sm">Approve</Button>
                              <Button onClick={() => rejectDonorMut.mutate(donorId)} disabled={rejectDonorMut.isLoading} size="sm">Reject</Button>
                              <Button onClick={async () => {
                                const message = window.prompt('Enter notification message');
                                if (!message) return;
                                let method = window.prompt('Delivery method (sms or email)', 'sms');
                                if (!method) method = 'sms';
                                method = method.toLowerCase();
                                if (method !== 'sms' && method !== 'email') { alert('Invalid method'); return; }
                                try {
                                  await notifyDonorMut.mutateAsync({ id: donorId, payload: { method: method as 'sms' | 'email', message } });
                                  alert('Notification queued (simulated)');
                                } catch (e: any) {
                                  alert('Failed to send notification: ' + (e?.message || String(e)));
                                }
                              }} disabled={notifyDonorMut.isLoading} size="sm">Notify</Button>
                            </div>
                          </div>
                        )}
                      </div>
                    );
                  })
                )}
              </div>
            )}
          </CardContent>
        </Card>
      </section>

      <section className="mb-6">
        <Card>
          <CardHeader>
            <CardTitle>Blood Centres</CardTitle>
          </CardHeader>
          <CardContent>
            {loadingCentres ? (
              <div>Loading centres...</div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full table-auto text-sm">
                  <thead>
                    <tr className="text-left border-b">
                      <th className="p-2">Name</th>
                      <th className="p-2">Address</th>
                      <th className="p-2">City</th>
                      <th className="p-2">Phone</th>
                      <th className="p-2">Approved</th>
                      <th className="p-2">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {(centres ?? []).length === 0 ? (
                      <tr>
                        <td className="p-4 text-sm text-muted-foreground" colSpan={6}>No centres found</td>
                      </tr>
                    ) : (
                      (centres ?? []).map((c: any) => {
                        const centreId = c._id ?? c.name;
                        return (
                          <tr key={centreId} className="border-b hover:bg-gray-50">
                            <td className="p-2">{c.name}</td>
                            <td className="p-2">{c.address}</td>
                            <td className="p-2">{c.city}</td>
                            <td className="p-2">{c.phone}</td>
                            <td className="p-2">{String(c.approved ?? false)}</td>
                            <td className="p-2">
                              <div className="flex gap-2">
                                <Button
                                  onClick={() => approveCentreMut.mutate(centreId)}
                                  disabled={approveCentreMut.isPending}
                                  size="sm"
                                  className="bg-green-600 hover:bg-green-700"
                                >
                                  Approve
                                </Button>
                                <Button
                                  onClick={() => rejectCentreMut.mutate(centreId)}
                                  disabled={rejectCentreMut.isPending}
                                  size="sm"
                                  className="bg-red-600 hover:bg-red-700"
                                >
                                  Reject
                                </Button>
                              </div>
                            </td>
                          </tr>
                        );
                      })
                    )}
                  </tbody>
                </table>
              </div>
            )}
          </CardContent>
        </Card>
      </section>

      <section className="mb-6">
        <Card>
          <CardHeader>
            <CardTitle>Donation Camps</CardTitle>
          </CardHeader>
          <CardContent>
            {loadingCamps ? (
              <div>Loading camps...</div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full table-auto text-sm">
                  <thead>
                    <tr className="text-left border-b">
                      <th className="p-2">Name</th>
                      <th className="p-2">Date</th>
                      <th className="p-2">Address</th>
                      <th className="p-2">Approved</th>
                      <th className="p-2">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {(camps ?? []).length === 0 ? (
                      <tr>
                        <td className="p-4 text-sm text-muted-foreground" colSpan={5}>No camps found</td>
                      </tr>
                    ) : (
                      (camps ?? []).map((c: any) => {
                        const campId = c._id ?? c.name;
                        const campDate = c.date ? new Date(c.date).toLocaleDateString() : 'N/A';
                        return (
                          <tr key={campId} className="border-b hover:bg-gray-50">
                            <td className="p-2">{c.name}</td>
                            <td className="p-2">{campDate}</td>
                            <td className="p-2">{c.address}</td>
                            <td className="p-2">{String(c.approved ?? false)}</td>
                            <td className="p-2">
                              <div className="flex gap-2">
                                <Button
                                  onClick={() => approveCampMut.mutate(campId)}
                                  disabled={approveCampMut.isPending}
                                  size="sm"
                                  className="bg-green-600 hover:bg-green-700"
                                >
                                  Approve
                                </Button>
                                <Button
                                  onClick={() => rejectCampMut.mutate(campId)}
                                  disabled={rejectCampMut.isPending}
                                  size="sm"
                                  className="bg-red-600 hover:bg-red-700"
                                >
                                  Reject
                                </Button>
                              </div>
                            </td>
                          </tr>
                        );
                      })
                    )}
                  </tbody>
                </table>
              </div>
            )}
          </CardContent>
        </Card>
      </section>

      <section className="mb-6">
        <Card>
          <CardHeader>
            <CardTitle>Volunteers</CardTitle>
          </CardHeader>
          <CardContent>
            <table className="w-full table-auto">
              <thead>
                <tr className="text-left">
                  <th className="p-2">Name</th>
                  <th className="p-2">Email</th>
                  <th className="p-2">City</th>
                  <th className="p-2">Phone</th>
                  <th className="p-2">Actions</th>
                </tr>
              </thead>
              <tbody>
                {(displayedVolunteers ?? []).length === 0 ? (
                  <tr>
                    <td className="p-4 text-sm text-muted-foreground" colSpan={5}>No volunteers found</td>
                  </tr>
                ) : (
                  (displayedVolunteers ?? []).map((v: any) => (
                    <tr key={v._id ?? v.email ?? v.name} className="border-t">
                      <td className="p-2">{v.name}</td>
                      <td className="p-2">{v.email}</td>
                      <td className="p-2">{v.city}</td>
                      <td className="p-2">{v.phone}</td>
                      <td className="p-2">
                        <div className="flex gap-2">
                          <Button className="bg-destructive text-white" onClick={() => {
                            if (!confirm('Delete this volunteer?')) return;
                            deleteVolunteerMut.mutate(v._id ?? v.email ?? v.name);
                          }} disabled={deleteVolunteerMut.isLoading}>Delete</Button>
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </CardContent>
        </Card>
      </section>
    </div>
  );
}
