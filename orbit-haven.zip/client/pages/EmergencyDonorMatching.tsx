import React, { useState } from 'react';
import { useLanguage } from '@/hooks/useLanguage';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { AlertCircle, CheckCircle, Zap } from 'lucide-react';

const BLOOD_GROUPS = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'];
const URGENCY_LEVELS = ['Low', 'Medium', 'High', 'Critical'];
const LOCATIONS = ['Vijayawada', 'Guntur', 'Hyderabad', 'Bengaluru', 'Mumbai', 'Delhi'];

export default function EmergencyDonorMatching() {
  const { t } = useLanguage();
  const [formData, setFormData] = useState({
    patientName: '',
    bloodGroup: '',
    location: '',
    urgencyLevel: '',
  });
  const [isLoading, setIsLoading] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setError(null);
    
    // Validate form
    if (!formData.patientName || !formData.bloodGroup || !formData.location || !formData.urgencyLevel) {
      setError('Please fill in all fields');
      return;
    }

    setIsLoading(true);
    
    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 2500));
    
    setIsLoading(false);
    setIsSuccess(true);
    
    // Reset form after 3 seconds
    setTimeout(() => {
      setFormData({
        patientName: '',
        bloodGroup: '',
        location: '',
        urgencyLevel: '',
      });
      setIsSuccess(false);
    }, 3000);
  };

  return (
    <div className="mx-auto max-w-2xl">
      <div className="mb-8">
        <div className="flex items-center gap-3 mb-2">
          <AlertCircle className="h-8 w-8 text-red-600" />
          <h1 className="text-3xl font-bold text-gray-900">Emergency AI Donor Matching</h1>
        </div>
        <p className="text-gray-600">
          Find and notify nearby eligible donors instantly for urgent blood requirements
        </p>
      </div>

      {isSuccess ? (
        <Card className="border-2 border-green-200 bg-green-50">
          <CardContent className="pt-12 pb-12">
            <div className="flex flex-col items-center text-center space-y-4">
              <CheckCircle className="h-16 w-16 text-green-600" />
              <div>
                <h2 className="text-2xl font-bold text-green-700 mb-2">Success!</h2>
                <p className="text-gray-700 mb-4">
                  Matching donors found. Notifications sent via <strong>Email and SMS.</strong>
                </p>
                <p className="text-sm text-gray-600">
                  Nearby donors have been notified about the urgent blood requirement for <strong>{formData.patientName}</strong>
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      ) : isLoading ? (
        <Card className="border-2 border-red-200 bg-red-50">
          <CardContent className="flex flex-col items-center justify-center py-16">
            <div className="animate-spin mb-4">
              <Zap className="h-12 w-12 text-red-600" />
            </div>
            <p className="text-lg font-medium text-gray-700">Finding and notifying nearby donors…</p>
          </CardContent>
        </Card>
      ) : (
        <Card className="border-2 border-red-200">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <AlertCircle className="h-5 w-5 text-red-600" />
              Patient Blood Request Form
            </CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Patient Name */}
              <div>
                <label htmlFor="patientName" className="block text-sm font-medium text-gray-700 mb-2">
                  Patient Name
                </label>
                <input
                  type="text"
                  id="patientName"
                  name="patientName"
                  value={formData.patientName}
                  onChange={handleInputChange}
                  placeholder="Enter patient name"
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-600 focus:border-transparent outline-none transition"
                  required
                />
              </div>

              {/* Blood Group */}
              <div>
                <label htmlFor="bloodGroup" className="block text-sm font-medium text-gray-700 mb-2">
                  Blood Group Required
                </label>
                <select
                  id="bloodGroup"
                  name="bloodGroup"
                  value={formData.bloodGroup}
                  onChange={handleInputChange}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-600 focus:border-transparent outline-none transition"
                  required
                >
                  <option value="">Select blood group</option>
                  {BLOOD_GROUPS.map((group) => (
                    <option key={group} value={group}>
                      {group}
                    </option>
                  ))}
                </select>
              </div>

              {/* Location */}
              <div>
                <label htmlFor="location" className="block text-sm font-medium text-gray-700 mb-2">
                  Location
                </label>
                <select
                  id="location"
                  name="location"
                  value={formData.location}
                  onChange={handleInputChange}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-600 focus:border-transparent outline-none transition"
                  required
                >
                  <option value="">Select location</option>
                  {LOCATIONS.map((loc) => (
                    <option key={loc} value={loc}>
                      {loc}
                    </option>
                  ))}
                </select>
              </div>

              {/* Urgency Level */}
              <div>
                <label htmlFor="urgencyLevel" className="block text-sm font-medium text-gray-700 mb-2">
                  Urgency Level
                </label>
                <select
                  id="urgencyLevel"
                  name="urgencyLevel"
                  value={formData.urgencyLevel}
                  onChange={handleInputChange}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-600 focus:border-transparent outline-none transition"
                  required
                >
                  <option value="">Select urgency level</option>
                  {URGENCY_LEVELS.map((level) => (
                    <option key={level} value={level}>
                      {level}
                    </option>
                  ))}
                </select>
              </div>

              {/* Error Message */}
              {error && (
                <div className="p-4 bg-red-100 border border-red-400 rounded-lg text-red-700 flex items-center gap-2">
                  <AlertCircle className="h-5 w-5" />
                  {error}
                </div>
              )}

              {/* Submit Button */}
              <Button
                type="submit"
                disabled={isLoading}
                className="w-full bg-red-600 hover:bg-red-700 text-white font-semibold py-3 rounded-lg transition-colors flex items-center justify-center gap-2"
              >
                <Zap className="h-5 w-5" />
                Find & Notify Donors
              </Button>

              <p className="text-xs text-gray-500 text-center mt-4">
                AI-powered emergency donor matching • Notifications sent instantly via Email & SMS
              </p>
            </form>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
