import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';

export default function AdminSignup() {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [hospitalId, setHospitalId] = useState('');
  const [error, setError] = useState<string | null>(null);
  const navigate = useNavigate();

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    try {
      const res = await fetch('/api/admin/signup', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ name, email, password, hospitalId }) });
      if (!res.ok) {
        const js = await res.json().catch(() => ({}));
        throw new Error(js.error || 'Signup failed');
      }
      // created, go to login
      navigate('/admin/login');
    } catch (err: any) {
      setError(err?.message || 'Signup failed');
    }
  }

  return (
    <div className="mx-auto max-w-md">
      <h1 className="text-2xl font-bold mb-4">Admin Signup</h1>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <Label className="text-sm">Name</Label>
          <Input value={name} onChange={(e) => setName(e.target.value)} />
        </div>
        <div>
          <Label className="text-sm">Email</Label>
          <Input value={email} onChange={(e) => setEmail(e.target.value)} />
        </div>
        <div>
          <Label className="text-sm">Password</Label>
          <Input type="password" value={password} onChange={(e) => setPassword(e.target.value)} />
        </div>
        <div>
          <Label className="text-sm">Hospital ID / Name</Label>
          <Input value={hospitalId} onChange={(e) => setHospitalId(e.target.value)} />
        </div>
        {error && <div className="text-sm text-destructive">{error}</div>}
        <div className="flex gap-2">
          <Button type="submit">Create Admin</Button>
        </div>
      </form>
    </div>
  );
}
