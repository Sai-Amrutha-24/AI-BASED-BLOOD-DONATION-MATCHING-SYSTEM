import React, { useEffect, useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { postDonor } from "@/lib/api";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select, SelectTrigger, SelectContent, SelectItem, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";

const BLOOD_GROUPS = ["A+","A-","B+","B-","AB+","AB-","O+","O-"];

type DonorForm = {
  name: string;
  age?: string;
  gender: string;
  address: string;
  phone: string;
  dob: string;
  email: string;
  hemoglobin?: string;
  bloodGroup: string;
  diseases?: string;
};

export default function RegisterDonor() {
  const [user, setUser] = useState<{ name: string; email?: string } | null>(null);
  const [mode, setMode] = useState<"login" | "signup">("login");
  const [authForm, setAuthForm] = useState({ name: "", email: "", password: "" });

  useEffect(() => {
    const raw = localStorage.getItem("bb_user");
    if (raw) setUser(JSON.parse(raw));
  }, []);

  const [form, setForm] = useState<DonorForm>({ name: "", age: "", gender: "", address: "", phone: "", dob: "", email: "", hemoglobin: "", bloodGroup: "", diseases: "" });

  const [errors, setErrors] = useState<Record<string, string>>({});
  const [showSuccess, setShowSuccess] = useState(false);
  const [debug, setDebug] = useState<{ status?: string; error?: string } | null>(null);

  const mutation = useMutation({
    mutationFn: (payload: any) => postDonor(payload),
    onMutate: () => {
      setDebug({ status: 'mutating' });
    },
    onSuccess: (data) => {
      // show success prominently
      // eslint-disable-next-line no-console
      console.debug('postDonor success', data);
      toast.success("Donor registered successfully");
      setShowSuccess(true);
      setForm({ name: "", age: "", gender: "", address: "", phone: "", dob: "", email: "", hemoglobin: "", bloodGroup: "", diseases: "" });
      setErrors({});
      setDebug({ status: 'success' });
      // scroll to the success message
      setTimeout(() => {
        const el = document.getElementById('donor-success');
        if (el) el.scrollIntoView({ behavior: 'smooth', block: 'center' });
      }, 50);
    },
    onError: (e: any) => {
      // eslint-disable-next-line no-console
      console.warn('postDonor error', e);
      toast.error(e?.message || "Failed to register donor");
      setDebug({ status: 'error', error: e?.message ?? String(e) });
    },
  });

  // clear success when user edits form
  useEffect(() => {
    setShowSuccess(false);
  }, [form.name, form.email, form.phone, form.bloodGroup]);

  function validate(): boolean {
    const e: Record<string, string> = {};
    if (!form.name.trim()) e.name = "Full name is required";
    if (!form.dob) e.dob = "Date of birth is required";
    if (!form.email || !/^\S+@\S+\.\S+$/.test(form.email)) e.email = "Valid email is required";
    if (!form.phone || !/^\+?[0-9\-\s]{7,15}$/.test(form.phone)) e.phone = "Valid phone is required";
    if (!form.address.trim()) e.address = "Address is required";
    if (!form.bloodGroup) e.bloodGroup = "Select blood group";
    if (!form.hemoglobin || isNaN(Number(form.hemoglobin)) || Number(form.hemoglobin) <= 0) e.hemoglobin = "Enter a valid hemoglobin value";
    if (!form.gender) e.gender = "Gender is required";
    // age optional if dob provided, but allow age if given
    setErrors(e);
    return Object.keys(e).length === 0;
  }

  function handleSubmit() {
    if (!validate()) return;
    const payload = {
      name: form.name,
      age: form.age ? Number(form.age) : undefined,
      gender: form.gender,
      bloodGroup: form.bloodGroup,
      lastDonationDate: undefined,
      phone: form.phone,
      city: form.address,
      email: form.email,
      dob: form.dob,
      hemoglobin: form.hemoglobin ? Number(form.hemoglobin) : undefined,
      diseases: form.diseases,
    };
    mutation.mutate(payload);
  }

  function handleSignup() {
    if (!authForm.name || !authForm.email) return toast.error("Name and email required");
    const u = { name: authForm.name, email: authForm.email };
    localStorage.setItem("bb_user", JSON.stringify(u));
    setUser(u);
    toast.success("Signed up");
  }

  function handleLogin() {
    const raw = localStorage.getItem("bb_user");
    if (!raw) return toast.error("No user found. Please sign up.");
    const u = JSON.parse(raw);
    if (u.email !== authForm.email) return toast.error("User not found");
    setUser(u);
    toast.success("Logged in");
  }

  if (!user) {
    return (
      <div className="mx-auto max-w-md">
        <Card>
          <CardHeader>
            <CardTitle>{mode === "login" ? "Login to Register" : "Sign up to Register"}</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-1">
              <Label className="text-sm">Name</Label>
              <Input value={authForm.name} onChange={(e) => setAuthForm((f) => ({ ...f, name: e.target.value }))} />
            </div>
            <div className="space-y-1">
              <Label className="text-sm">Email</Label>
              <Input value={authForm.email} onChange={(e) => setAuthForm((f) => ({ ...f, email: e.target.value }))} />
            </div>
            <div className="space-y-1">
              <Label className="text-sm">Password</Label>
              <Input type="password" value={authForm.password} onChange={(e) => setAuthForm((f) => ({ ...f, password: e.target.value }))} />
            </div>

            <div className="flex gap-2">
              <Button className="bg-primary text-primary-foreground" onClick={mode === "login" ? handleLogin : handleSignup}>{mode === "login" ? "Login" : "Sign up"}</Button>
              <Button onClick={() => setMode(mode === "login" ? "signup" : "login")}>{mode === "login" ? "Switch to Sign up" : "Switch to Login"}</Button>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-2xl">
      <Card>
        <CardHeader>
          <CardTitle>Register Donor</CardTitle>
          <div className="text-sm text-muted-foreground">Logged in as <strong>{user.name}</strong></div>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-1">
            <Label className="text-sm">Full Name</Label>
            <Input value={form.name} onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))} />
            {errors.name && <div className="text-sm text-destructive">{errors.name}</div>}
          </div>

          <div className="grid grid-cols-3 gap-3">
            <div className="space-y-1">
              <Label className="text-sm">Date of Birth</Label>
              <Input type="date" value={form.dob} onChange={(e) => setForm((f) => ({ ...f, dob: e.target.value }))} />
              {errors.dob && <div className="text-sm text-destructive">{errors.dob}</div>}
            </div>
            <div className="space-y-1">
              <Label className="text-sm">Age</Label>
              <Input value={form.age} onChange={(e) => setForm((f) => ({ ...f, age: e.target.value }))} />
            </div>
            <div className="space-y-1">
              <Label className="text-sm">Gender</Label>
              <Select value={form.gender} onValueChange={(v) => setForm((f) => ({ ...f, gender: v }))}>
                <SelectTrigger>
                  <SelectValue placeholder="Select gender" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Male">Male</SelectItem>
                  <SelectItem value="Female">Female</SelectItem>
                  <SelectItem value="Other">Other</SelectItem>
                </SelectContent>
              </Select>
              {errors.gender && <div className="text-sm text-destructive">{errors.gender}</div>}
            </div>
          </div>

          <div className="space-y-1">
            <Label className="text-sm">Address</Label>
            <Input value={form.address} onChange={(e) => setForm((f) => ({ ...f, address: e.target.value }))} />
            {errors.address && <div className="text-sm text-destructive">{errors.address}</div>}
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1">
              <Label className="text-sm">Phone</Label>
              <Input value={form.phone} onChange={(e) => setForm((f) => ({ ...f, phone: e.target.value }))} />
              {errors.phone && <div className="text-sm text-destructive">{errors.phone}</div>}
            </div>
            <div className="space-y-1">
              <Label className="text-sm">Email</Label>
              <Input value={form.email} onChange={(e) => setForm((f) => ({ ...f, email: e.target.value }))} />
              {errors.email && <div className="text-sm text-destructive">{errors.email}</div>}
            </div>
          </div>

          <div className="grid grid-cols-3 gap-3">
            <div className="space-y-1">
              <Label className="text-sm">Hemoglobin (g/dL)</Label>
              <Input value={form.hemoglobin} onChange={(e) => setForm((f) => ({ ...f, hemoglobin: e.target.value }))} />
              {errors.hemoglobin && <div className="text-sm text-destructive">{errors.hemoglobin}</div>}
            </div>
            <div className="space-y-1">
              <Label className="text-sm">Blood Group</Label>
              <Select value={form.bloodGroup} onValueChange={(v) => setForm((f) => ({ ...f, bloodGroup: v }))}>
                <SelectTrigger>
                  <SelectValue placeholder="Select group" />
                </SelectTrigger>
                <SelectContent>
                  {BLOOD_GROUPS.map((g) => (
                    <SelectItem key={g} value={g}>{g}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {errors.bloodGroup && <div className="text-sm text-destructive">{errors.bloodGroup}</div>}
            </div>
            <div className="space-y-1">
              <Label className="text-sm">Existing Diseases (if any)</Label>
              <Input value={form.diseases} onChange={(e) => setForm((f) => ({ ...f, diseases: e.target.value }))} />
            </div>
          </div>

          <div className="flex gap-3">
            <Button className="bg-primary text-primary-foreground" onClick={handleSubmit} disabled={mutation.isLoading}>Submit Registration</Button>
            <Button onClick={() => { localStorage.removeItem("bb_user"); setUser(null); toast.success("Logged out"); }}>Logout</Button>
          </div>

          {(mutation.isSuccess || showSuccess) && (
            <div id="donor-success" className="rounded-md border p-4 text-center">
              <div className="font-semibold">Registration successful</div>
              <div className="text-sm text-muted-foreground">Thank you for registering as a donor. We will contact you when your blood group is needed.</div>
            </div>
          )}

          {/* Debug area */}
          {debug && (
            <div className="mt-4 rounded-md border p-3 bg-yellow-50 text-sm">
              <div className="font-semibold">Debug</div>
              <div>Status: {debug.status}</div>
              {debug.error && <div>Error: {debug.error}</div>}
              <div>Mutation state: {mutation.status}</div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="space-y-1">
      <Label className="text-sm">{label}</Label>
      {children}
    </div>
  );
}
