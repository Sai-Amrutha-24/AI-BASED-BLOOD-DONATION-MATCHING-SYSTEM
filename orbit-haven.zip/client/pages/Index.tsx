import { Link } from "react-router-dom";
import { Search, Building2, Users, User, Clipboard, Droplet } from 'lucide-react';

export default function Index() {
  const services = [
    { title: "Blood Availability Search", desc: "Find available blood types and locations near you instantly.", href: "/availability", icon: (
      <div className="relative flex items-center justify-center">
        <Search className="h-12 w-12 text-red-700" />
        <Droplet className="absolute -bottom-1 -right-1 h-5 w-5 text-white stroke-red-700" />
      </div>
    )},
    { title: "Blood Centre Directory", desc: "Complete directory of certified blood centres and hospitals.", href: "/centres", icon: <Building2 className="h-12 w-12 text-red-700" /> },
    { title: "Blood Donation Camps", desc: "Find and register for upcoming blood donation camps.", href: "/camps", icon: <Users className="h-12 w-12 text-red-700" /> },
    { title: "Donor Login", desc: "Access your donor profile and donation history.", href: "/donors", icon: <User className="h-12 w-12 text-red-700" /> },
    { title: "Register as Volunteer", desc: "Join our volunteer network and help save lives.", href: "/register", icon: <Clipboard className="h-12 w-12 text-red-700" /> },
    { title: "Register Blood Camp", desc: "Register your organization's blood donation camp.", href: "/camps", icon: <Clipboard className="h-12 w-12 text-red-700" /> },
  ];

  return (
    <div className="mx-auto max-w-7xl space-y-6">
      <header className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">Our Services</h1>
        <div className="flex gap-2">
          <Link to="/donor-register" className="btn-primary px-4 py-2">Register as Donor</Link>
          <Link to="/register" className="rounded-md border px-4 py-2">Volunteer</Link>
        </div>
      </header>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {services.map((s) => (
          <Link key={s.title} to={s.href} className="group block rounded-md border bg-card p-6 hover:shadow-md focus:outline-none focus:ring-2" aria-label={s.title}>
            <div className="flex flex-col items-center text-center gap-4">
              {s.icon}

              <div>
                <h3 className="text-sm font-semibold text-foreground group-hover:text-primary">{s.title}</h3>
                <p className="mt-2 text-sm text-muted-foreground">{s.desc}</p>
              </div>
            </div>
          </Link>
        ))}
      </div>
    </div>
  );
}
