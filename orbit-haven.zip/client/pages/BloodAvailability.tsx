import { useQuery } from "@tanstack/react-query";
import { getStocks } from "@/lib/api";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";

const target = 100;

export default function BloodAvailability() {
  const { data } = useQuery({ queryKey: ["stocks"], queryFn: getStocks });
  return (
    <div className="mx-auto grid max-w-5xl gap-4">
      <Card>
        <CardHeader>
          <CardTitle>Blood Availability by Group</CardTitle>
        </CardHeader>
        <CardContent className="grid gap-4 sm:grid-cols-2">
          {(data ?? []).map((s) => (
            <div key={s.group} className="rounded-md border p-4">
              <div className="mb-2 flex items-center justify-between">
                <span className="font-semibold">{s.group}</span>
                <span className="text-sm text-muted-foreground">{s.units} / {target} units</span>
              </div>
              <Progress value={Math.min(100, (s.units / target) * 100)} className={s.units < 30 ? "bg-destructive/20" : undefined} />
            </div>
          ))}
        </CardContent>
      </Card>
    </div>
  );
}
