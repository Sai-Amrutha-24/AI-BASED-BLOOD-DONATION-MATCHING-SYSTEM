import React from 'react';
import { Link, NavLink, Outlet, useLocation } from "react-router-dom";
import {
  Sidebar,
  SidebarProvider,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarHeader,
  SidebarInset,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarSeparator,
  SidebarTrigger,
} from "@/components/ui/sidebar";
import { Button } from "@/components/ui/button";
import { Home, Droplet, Building2, Users, Calendar, UserPlus, MapPin, Info, Flame, User, Shield, Zap, AlertCircle } from "lucide-react";
import NotificationBell from "@/components/NotificationBell";
import LanguageSwitcher from "@/components/LanguageSwitcher";
import { Separator } from "@/components/ui/separator";
import { useLanguage } from "@/hooks/useLanguage";

export default function RootLayout() {
  const location = useLocation();
  const { t } = useLanguage();

  const items = [
    { to: "/", labelKey: "home", icon: Home },
    { to: "/availability", labelKey: "bloodAvailability", icon: Droplet },
    { to: "/centres", labelKey: "bloodCentres", icon: Building2 },
    { to: "/camps", labelKey: "camps", icon: Calendar },
    { to: "/ai-matching", labelKey: "aiDonorMatching", icon: Zap },
    { to: "/emergency-matching", labelKey: "emergencyMatching", icon: AlertCircle },
    { to: "/register", labelKey: "registerVolunteer", icon: UserPlus },
    { to: "/donor-register", labelKey: "registerDonor", icon: User },
    { to: "/maps", labelKey: "maps", icon: MapPin },
    { to: "/about", labelKey: "aboutUs", icon: Info },
    { to: "/admin", labelKey: "admin", icon: Shield },
  ];
  return (
    <SidebarProvider>
      <Sidebar variant="inset" collapsible="icon" className="bg-sidebar">
        <SidebarHeader className="p-4">
          <Link to="/" className="inline-flex items-center gap-2">
            <Flame className="h-6 w-6 text-red-600" />
            <span className="font-extrabold tracking-tight text-red-700">BloodBank</span>
            <span className="ml-2 inline-block rounded-full bg-green-500/20 px-2 py-0.5 text-xs font-medium text-green-700">Donate</span>
          </Link>
        </SidebarHeader>
        <SidebarContent>
          <SidebarGroup>
            <SidebarGroupContent>
              <SidebarMenu>
                {items.map((item) => (
                  <SidebarMenuItem key={item.to}>
                    <SidebarMenuButton asChild isActive={location.pathname === item.to}>
                      <NavLink to={item.to} className={({ isActive }) => (isActive ? "data-[active=true]" : undefined)}>
                        <item.icon />
                        <span>{t(item.labelKey as any)}</span>
                      </NavLink>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                ))}
              </SidebarMenu>
            </SidebarGroupContent>
          </SidebarGroup>
        </SidebarContent>
      </Sidebar>

      <SidebarInset>
        <header className="sticky top-0 z-20 flex h-16 items-center gap-3 border-b bg-background/80 px-4 backdrop-blur supports-[backdrop-filter]:bg-background/60">
          <SidebarTrigger />
          <Separator orientation="vertical" className="mr-2 h-6" />
          <div className="flex-1 text-lg font-semibold tracking-tight">{t('bloodBankManagement')}</div>
          <LanguageSwitcher />
          <NotificationBell />
          <Button asChild className="ml-2 bg-red-600 text-white hover:bg-red-700">
            <a href="/register">{t('becomeVolunteer')}</a>
          </Button>
        </header>
        <main className="min-h-[calc(100svh-4rem)] bg-gradient-to-b from-accent/40 to-background p-4">
          <Outlet />
        </main>
        <footer className="border-t p-4 text-center text-sm text-muted-foreground">© {new Date().getFullYear()} BloodBank. Saving lives together.</footer>
      </SidebarInset>
    </SidebarProvider>
  );
}
