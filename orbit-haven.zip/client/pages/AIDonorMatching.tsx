import React from 'react';
import { useLanguage } from '@/hooks/useLanguage';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Zap, MapPin, Phone, Droplet } from 'lucide-react';

interface Donor {
  id: string;
  name: string;
  bloodGroup: string;
  distance: number;
  available: boolean;
  lastDonationDate: string;
  phone: string;
}

export default function AIDonorMatching() {
  const { t } = useLanguage();
  const [isLoading, setIsLoading] = React.useState(true);
  const [donors, setDonors] = React.useState<Donor[]>([]);

  React.useEffect(() => {
    // Simulate loading donors
    const timer = setTimeout(() => {
      setDonors([
        {
          id: '1',
          name: 'Rajesh Kumar',
          bloodGroup: 'A+',
          distance: 2.3,
          available: true,
          lastDonationDate: '2025-01-15',
          phone: '+91 90123 45678',
        },
        {
          id: '2',
          name: 'Priya Desai',
          bloodGroup: 'A+',
          distance: 4.1,
          available: true,
          lastDonationDate: '2024-11-20',
          phone: '+91 91234 56789',
        },
        {
          id: '3',
          name: 'Arjun Patel',
          bloodGroup: 'A+',
          distance: 5.7,
          available: false,
          lastDonationDate: '2025-01-10',
          phone: '+91 92345 67890',
        },
        {
          id: '4',
          name: 'Sneha Gupta',
          bloodGroup: 'A+',
          distance: 6.2,
          available: true,
          lastDonationDate: '2024-12-05',
          phone: '+91 93456 78901',
        },
      ]);
      setIsLoading(false);
    }, 2000);

    return () => clearTimeout(timer);
  }, []);

  const handleContact = (phone: string) => {
    window.open(`tel:${phone}`);
  };

  return (
    <div className="mx-auto max-w-7xl">
      <div className="mb-8">
        <div className="flex items-center gap-3 mb-2">
          <Zap className="h-8 w-8 text-red-600" />
          <h1 className="text-3xl font-bold text-gray-900">{t('aiDonorMatching')}</h1>
        </div>
        <p className="text-gray-600 max-w-2xl">{t('aiMatchingDesc')}</p>
      </div>

      {isLoading ? (
        <Card className="border-2 border-red-200 bg-red-50">
          <CardContent className="flex flex-col items-center justify-center py-16">
            <div className="animate-spin mb-4">
              <Droplet className="h-12 w-12 text-red-600" />
            </div>
            <p className="text-lg font-medium text-gray-700">{t('findingDonors')}</p>
          </CardContent>
        </Card>
      ) : (
        <>
          {donors.length === 0 ? (
            <Card className="border-2 border-red-200">
              <CardContent className="py-12 text-center">
                <p className="text-gray-600">{t('noDonorsFound')}</p>
              </CardContent>
            </Card>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {donors.map((donor) => (
                <Card
                  key={donor.id}
                  className="border-2 border-gray-200 hover:border-red-300 hover:shadow-lg transition-all duration-200"
                >
                  <CardHeader className="pb-3">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <CardTitle className="text-xl text-gray-900">
                          {donor.name}
                        </CardTitle>
                        <p className="text-sm text-gray-500 mt-1">
                          {donor.lastDonationDate}
                        </p>
                      </div>
                      <Badge className="bg-red-100 text-red-700 hover:bg-red-100">
                        {donor.bloodGroup}
                      </Badge>
                    </div>
                  </CardHeader>

                  <CardContent className="space-y-4">
                    {/* Distance */}
                    <div className="flex items-center gap-2">
                      <MapPin className="h-4 w-4 text-red-600" />
                      <span className="text-sm text-gray-700">
                        <span className="font-semibold">{donor.distance} km</span> {t('distance')}
                      </span>
                    </div>

                    {/* Availability */}
                    <div className="flex items-center gap-2">
                      <div
                        className={`h-3 w-3 rounded-full ${
                          donor.available ? 'bg-green-500' : 'bg-gray-400'
                        }`}
                      />
                      <span className="text-sm text-gray-700">
                        {donor.available ? (
                          <span className="font-semibold text-green-600">
                            {t('available')}
                          </span>
                        ) : (
                          <span className="font-semibold text-gray-600">
                            {t('notAvailable')}
                          </span>
                        )}
                      </span>
                    </div>

                    {/* Last Donation Date */}
                    <div className="flex items-center gap-2 text-sm">
                      <Droplet className="h-4 w-4 text-red-600" />
                      <span className="text-gray-700">
                        <span className="font-semibold">{t('lastDonationDate')}:</span>{' '}
                        {new Date(donor.lastDonationDate).toLocaleDateString()}
                      </span>
                    </div>

                    {/* AI Badge */}
                    <div className="pt-2 border-t">
                      <Badge
                        variant="outline"
                        className="text-xs border-red-300 text-red-600 bg-red-50 hover:bg-red-50"
                      >
                        {t('aiPoweredMatching')}
                      </Badge>
                    </div>

                    {/* Contact Button */}
                    <Button
                      onClick={() => handleContact(donor.phone)}
                      disabled={!donor.available}
                      className={`w-full mt-4 ${
                        donor.available
                          ? 'bg-red-600 hover:bg-red-700 text-white'
                          : 'bg-gray-300 text-gray-500 cursor-not-allowed'
                      }`}
                    >
                      <Phone className="h-4 w-4 mr-2" />
                      {t('contactNow')}
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </>
      )}
    </div>
  );
}
