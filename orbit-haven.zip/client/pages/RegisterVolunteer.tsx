import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { postVolunteer } from "@/lib/api";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";

export default function RegisterVolunteer() {
  const [form, setForm] = useState({ name: "", email: "", phone: "", city: "" });
  const mutation = useMutation({ mutationFn: postVolunteer, onSuccess: () => { toast.success("Thanks for registering as a volunteer!"); setForm({ name: "", email: "", phone: "", city: "" });
      try {
        localStorage.setItem('bb_volunteer_updated', String(Date.now()));
      } catch (e) { /* ignore */ }
      try { window.dispatchEvent(new Event('bb_volunteer_updated')); } catch (e) { /* ignore */ }
    } });

  return (
    <div className="mx-auto max-w-xl">
      <Card>
        <CardHeader>
          <CardTitle>Register as a Volunteer</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <Field label="Full Name">
            <Input value={form.name} onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))} required />
          </Field>
          <Field label="Email">
            <Input type="email" value={form.email} onChange={(e) => setForm((f) => ({ ...f, email: e.target.value }))} />
          </Field>
          <Field label="Phone">
            <Input value={form.phone} onChange={(e) => setForm((f) => ({ ...f, phone: e.target.value }))} />
          </Field>
          <Field label="City">
            <Input value={form.city} onChange={(e) => setForm((f) => ({ ...f, city: e.target.value }))} />
          </Field>
          <Button className="w-full bg-primary" onClick={() => mutation.mutate(form)} disabled={!form.name || mutation.isPending}>
            {mutation.isPending ? "Submitting..." : "Register"}
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="space-y-1">
      <Label className="text-sm">{label}</Label>
      {children}
    </div>
  );
}
