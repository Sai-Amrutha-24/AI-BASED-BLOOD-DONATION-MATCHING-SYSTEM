import { useQuery } from "@tanstack/react-query";
import { getStats, getStocks } from "@/lib/api";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Droplet, Users, Building2, Calendar, Search, User, Clipboard } from "lucide-react";
import { ResponsiveContainer, AreaChart, Area, XAxis, YAxis, Tooltip } from "recharts";
import { Link } from "react-router-dom";

export default function Dashboard() {
  const { data: stats } = useQuery({ queryKey: ["stats"], queryFn: getStats });
  const { data: stocks } = useQuery({ queryKey: ["stocks"], queryFn: getStocks });

  const services = [
    { title: "Blood Availability Search", desc: "Find available blood types and locations near you instantly.", href: "/availability", icon: (
      <div className="relative flex items-center justify-center">
        <Search className="h-16 w-16 text-red-700" />
        <Droplet className="absolute -bottom-1 -right-1 h-5 w-5 text-white stroke-red-700" />
      </div>
    )},
    { title: "Blood Centre Directory", desc: "Complete directory of certified blood centres and hospitals.", href: "/centres", icon: <Building2 className="h-16 w-16 text-red-700" /> },
    { title: "Blood Donation Camps", desc: "Find and register for upcoming blood donation camps.", href: "/camps", icon: <Users className="h-16 w-16 text-red-700" /> },
    { title: "Donor Login", desc: "Access your donor profile and donation history.", href: "/donors", icon: <User className="h-16 w-16 text-red-700" /> },
    { title: "Register as Volunteer", desc: "Join our volunteer network and help save lives.", href: "/register", icon: <Clipboard className="h-16 w-16 text-red-700" /> },
    { title: "Register Blood Camp", desc: "Register your organization's blood donation camp.", href: "/camps", icon: <Clipboard className="h-16 w-16 text-red-700" /> },
  ];

  return (
    <div className="mx-auto grid max-w-7xl gap-6">
      {/* Hero banner */}
      <section className="rounded-lg bg-gradient-to-r from-red-600 to-red-500 text-white shadow-lg overflow-hidden">
        <div className="mx-auto max-w-7xl px-6 py-12 lg:flex lg:items-center lg:justify-between">
          <div className="max-w-2xl">
            <h1 className="text-3xl font-extrabold sm:text-4xl lg:text-5xl">Donate Blood. Save Lives.</h1>
            <p className="mt-4 text-lg text-red-100/90">Join our community of donors and help patients in need. Find available blood, register as a donor, or volunteer at nearby camps.</p>
            <div className="mt-6 flex flex-wrap gap-3">
              <Link to="/register" className="inline-flex items-center gap-2 rounded-md bg-white px-5 py-3 text-sm font-semibold text-red-700 shadow hover:shadow-md transform transition hover:-translate-y-0.5">Donate</Link>
              <Link to="/availability" className="inline-flex items-center gap-2 rounded-md border border-white/30 px-5 py-3 text-sm font-semibold text-white hover:bg-white/10 transition">Find Blood</Link>
            </div>
          </div>

          <div className="mt-8 lg:mt-0">
            <div className="rounded-lg bg-white/10 p-6 backdrop-blur-sm">
              <div className="flex items-center gap-4">
                <Droplet className="h-12 w-12 text-white stroke-white" />
                <div>
                  <div className="text-sm text-red-100">Available Units Today</div>
                  <div className="text-2xl font-bold">{stats?.totalUnits ?? 0}</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Quick stats */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard icon={<Droplet className="text-red-600" />} title="Total Units" value={stats?.totalUnits ?? 0} />
        <StatCard icon={<Users className="text-red-600" />} title="Donors" value={stats?.totalDonors ?? 0} />
        <StatCard icon={<Building2 className="text-red-600" />} title="Centres" value={stats?.totalCentres ?? 0} />
        <StatCard icon={<Calendar className="text-red-600" />} title="Upcoming Camps" value={stats?.upcomingCamps ?? 0} />
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <Card className="overflow-hidden">
          <CardHeader>
            <CardTitle>Blood Stock Distribution</CardTitle>
          </CardHeader>
          <CardContent className="h-72">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={(stocks ?? []).map((s) => ({ name: s.group, units: s.units }))}>
                <defs>
                  <linearGradient id="blood" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="hsl(var(--primary))" stopOpacity={0.8} />
                    <stop offset="95%" stopColor="hsl(var(--primary))" stopOpacity={0.1} />
                  </linearGradient>
                </defs>
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip />
                <Area type="monotone" dataKey="units" stroke="hsl(var(--primary))" fill="url(#blood)" />
              </AreaChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Low Stock Alerts</CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="grid grid-cols-2 gap-2 sm:grid-cols-3">
              {(stats?.lowStock ?? []).map((l) => (
                <li key={l.group} className="rounded-md border p-3 text-center">
                  <div className="text-sm text-muted-foreground">{l.group}</div>
                  <div className="text-2xl font-bold text-destructive">{l.units}</div>
                  <div className="text-xs text-muted-foreground">units</div>
                </li>
              ))}
              {(stats?.lowStock?.length ?? 0) === 0 && (
                <div className="text-sm text-muted-foreground">No low stock groups.</div>
              )}
            </ul>
          </CardContent>
        </Card>
      </div>

      <section>
        <header className="flex items-center justify-between">
          <h2 className="text-xl font-bold">Our Services</h2>
        </header>

        <div className="mt-4 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {services.map((s) => (
            <Link key={s.title} to={s.href} className="group block rounded-lg border bg-card p-6 hover:shadow-xl hover:scale-[1.02] transform transition duration-200 focus:outline-none focus:ring-2" aria-label={s.title}>
              <div className="flex flex-col items-center text-center gap-4">
                {s.icon}

                <div>
                  <h3 className="text-sm font-semibold text-foreground group-hover:text-primary">{s.title}</h3>
                  <p className="mt-2 text-sm text-muted-foreground">{s.desc}</p>
                </div>
              </div>
            </Link>
          ))}
        </div>
      </section>
    </div>
  );
}

function StatCard({ icon, title, value }: { icon: React.ReactNode; title: string; value: number }) {
  return (
    <Card>
      <CardContent className="flex items-center justify-between p-6">
        <div>
          <div className="text-sm text-muted-foreground">{title}</div>
          <div className="text-3xl font-extrabold">{value}</div>
        </div>
        <div className="rounded-full bg-accent p-3">{icon}</div>
      </CardContent>
    </Card>
  );
}
