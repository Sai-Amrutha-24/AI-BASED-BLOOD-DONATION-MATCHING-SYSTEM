import { useQuery } from "@tanstack/react-query";
import { getCamps } from "@/lib/api";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Calendar } from "lucide-react";

export default function DonationCamps() {
  const { data } = useQuery({ queryKey: ["camps"], queryFn: getCamps });
  return (
    <div className="mx-auto max-w-5xl">
      <Card>
        <CardHeader>
          <CardTitle>Upcoming Donation Camps</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {(data ?? []).map((c) => (
            <div key={c.name} className="flex items-center justify-between rounded-md border p-3">
              <div>
                <div className="font-semibold">{c.name}</div>
                {c.address && <div className="text-sm text-muted-foreground">{c.address}</div>}
              </div>
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <Calendar className="h-4 w-4 text-primary" /> {new Date(c.date).toLocaleDateString()}
              </div>
            </div>
          ))}
        </CardContent>
      </Card>
    </div>
  );
}
