import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';

export default function AdminLogin() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);

    if (!email || !password) {
      setError('Please enter email and password.');
      return;
    }

    setLoading(true);
    try {
      const res = await fetch('/api/admin/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ email, password }) });
      // Try to parse JSON body for better error messages
      const js = await res.json().catch(() => ({}));
      if (!res.ok) {
        // Prefer server message, then status text
        const msg = js?.error || js?.message || res.statusText || 'Login failed';
        // Map some status codes to friendlier messages
        if (res.status === 401) setError(msg || 'Invalid credentials');
        else if (res.status === 429) setError(msg || 'Too many attempts, try later');
        else setError(msg);
        setLoading(false);
        return;
      }

      const data = js;
      if (!data?.token) {
        setError('Login succeeded but no token returned from server.');
        setLoading(false);
        return;
      }

      localStorage.setItem('bb_admin_token', data.token);
      localStorage.setItem('bb_admin', JSON.stringify(data.admin));
      navigate('/admin');
    } catch (err: any) {
      setError(err?.message || 'Network error while trying to login');
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="mx-auto max-w-md">
      <h1 className="text-2xl font-bold mb-4">Admin Login</h1>
      <form onSubmit={handleSubmit} className="space-y-4" aria-live="polite">
        <div>
          <Label className="text-sm">Email</Label>
          <Input value={email} onChange={(e) => setEmail(e.target.value)} className={error ? 'border-destructive' : ''} />
        </div>
        <div>
          <Label className="text-sm">Password</Label>
          <Input type="password" value={password} onChange={(e) => setPassword(e.target.value)} className={error ? 'border-destructive' : ''} />
        </div>
        {error && <div className="text-sm text-destructive">{error}</div>}
        <div className="flex gap-2">
          <Button type="submit" disabled={loading}>{loading ? 'Logging in...' : 'Login'}</Button>
        </div>
      </form>
    </div>
  );
}
