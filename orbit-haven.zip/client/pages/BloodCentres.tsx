import { useQuery } from "@tanstack/react-query";
import { getCentres } from "@/lib/api";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { MapPin, Phone } from "lucide-react";

export default function BloodCentres() {
  const { data } = useQuery({ queryKey: ["centres"], queryFn: getCentres });
  return (
    <div className="mx-auto grid max-w-5xl gap-4 sm:grid-cols-2 lg:grid-cols-3">
      {(data ?? []).map((c) => (
        <Card key={c.name} className="border-primary/20">
          <CardHeader>
            <CardTitle className="text-lg">{c.name}</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2 text-sm">
            <div className="flex items-start gap-2 text-muted-foreground">
              <MapPin className="mt-0.5 h-4 w-4 text-primary" /> {c.address}
            </div>
            {c.phone && (
              <div className="flex items-center gap-2 text-muted-foreground">
                <Phone className="h-4 w-4 text-primary" /> {c.phone}
              </div>
            )}
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
