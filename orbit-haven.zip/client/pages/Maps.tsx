import React, { useEffect, useMemo, useState, useCallback } from "react";
import { MapContainer, TileLayer, Marker, Popup, useMap } from "react-leaflet";
import L from "leaflet";
import { getCentres, getDonors } from "@/lib/api";

const BLOOD_GROUPS = ["A+","A-","B+","B-","AB+","AB-","O+","O-"];

const DefaultMarker = new L.Icon({
  iconUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png",
  iconRetinaUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png",
  shadowUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png",
  iconSize: [25, 41],
  iconAnchor: [12, 41],
});

function haversineMeters(a: { latitude: number; longitude: number }, b: { latitude: number; longitude: number }) {
  const toRad = (v: number) => (v * Math.PI) / 180;
  const R = 6371e3; // meters
  const φ1 = toRad(a.latitude);
  const φ2 = toRad(b.latitude);
  const Δφ = toRad(b.latitude - a.latitude);
  const Δλ = toRad(b.longitude - a.longitude);
  const sa = Math.sin(Δφ / 2) * Math.sin(Δφ / 2) + Math.cos(φ1) * Math.cos(φ2) * Math.sin(Δλ / 2) * Math.sin(Δλ / 2);
  const c = 2 * Math.atan2(Math.sqrt(sa), Math.sqrt(1 - sa));
  return R * c;
}

function FitBounds({ points }: { points: Array<[number, number]> }) {
  const map = useMap();
  useEffect(() => {
    if (!map) return;
    if (!points || points.length === 0) return;
    map.fitBounds(points as any, { padding: [50, 50] });
  }, [map, points]);
  return null;
}

function MapEvents({ onCenter }: { onCenter: (c: { lat: number; lng: number }) => void }) {
  const map = useMap();
  useEffect(() => {
    if (!map) return;
    const report = () => onCenter(map.getCenter());
    report();
    map.on('moveend', report);
    return () => map.off('moveend', report);
  }, [map, onCenter]);
  return null;
}

export default function Maps() {
  const [centres, setCentres] = useState<any[]>([]);
  const [donors, setDonors] = useState<any[]>([]);
  const [position, setPosition] = useState<{ latitude: number; longitude: number } | null>(null);
  const [mapCenter, setMapCenter] = useState<{ latitude: number; longitude: number } | null>(null);
  const handleCenter = useCallback((c: { lat: number; lng: number }) => {
    setMapCenter((prev) => {
      if (prev && Math.abs(prev.latitude - c.lat) < 1e-6 && Math.abs(prev.longitude - c.lng) < 1e-6) return prev;
      return { latitude: c.lat, longitude: c.lng };
    });
  }, []);
  const [nearby, setNearby] = useState<{ type: "centre" | "donor"; item: any; distance: number }[]>([]);
  const [error, setError] = useState<string | null>(null);

  const [searchGroup, setSearchGroup] = useState("");
  const [searchResults, setSearchResults] = useState<any[] | null>(null);

  useEffect(() => {
    // Inject Leaflet stylesheet from CDN if not available
    if (!document.getElementById("leaflet-css")) {
      const link = document.createElement("link");
      link.id = "leaflet-css";
      link.rel = "stylesheet";
      link.href = "https://unpkg.com/leaflet@1.9.4/dist/leaflet.css";
      document.head.appendChild(link);
    }

    getCentres().then(setCentres).catch(() => setCentres([]));
    getDonors().then(setDonors).catch(() => setDonors([]));

    if (!navigator.geolocation) {
      setError("Geolocation is not supported by your browser");
      return;
    }

    navigator.geolocation.getCurrentPosition(
      (pos) => setPosition({ latitude: pos.coords.latitude, longitude: pos.coords.longitude }),
      (err) => setError(err.message || "Unable to retrieve your location"),
      { enableHighAccuracy: true, timeout: 10000 },
    );
  }, []);

  // Dev helper: simulate a location (Vijayawada)
  function simulateLocation() {
    const vijayawada = { latitude: 16.5062, longitude: 80.6480 };
    setPosition(vijayawada);
    setMapCenter({ latitude: vijayawada.latitude, longitude: vijayawada.longitude });
    setError(null);
  }

  // Search across all blood groups and merge results (useful for testing)
  async function searchAllGroups() {
    setSearchResults(null);
    const center = position ?? (mapCenter ? { latitude: mapCenter.latitude, longitude: mapCenter.longitude } : null);
    if (!center) {
      // simulate a location then proceed
      simulateLocation();
      // give state a moment to update
      await new Promise((r) => setTimeout(r, 300));
    }
    const useCenter = position ?? (mapCenter ? { latitude: mapCenter.latitude, longitude: mapCenter.longitude } : null);
    if (!useCenter) {
      setSearchResults([]);
      return;
    }

    try {
      const combined: any[] = [];
      for (const g of BLOOD_GROUPS) {
        const q = new URLSearchParams({ lat: String(useCenter.latitude), lng: String(useCenter.longitude), group: g, radiusMeters: "5000" });
        const res = await fetch(`/api/search-by-group?${q.toString()}`);
        if (!res.ok) continue;
        const data = await res.json();
        if (Array.isArray(data) && data.length > 0) {
          combined.push(...data);
        }
      }
      if (combined.length > 0) {
        // dedupe by name+type+latitude+longitude
        const seen = new Set();
        const deduped = combined.filter((r) => {
          const key = `${r.type||'centre'}|${r.name}|${r.latitude}|${r.longitude}`;
          if (seen.has(key)) return false;
          seen.add(key);
          return true;
        });
        deduped.sort((a, b) => (a.distance || 0) - (b.distance || 0));
        setSearchResults(deduped);
      } else {
        setSearchResults([]);
      }
    } catch (e) {
      console.error('searchAllGroups failed', e);
      setSearchResults([]);
    }
  }

  useEffect(() => {
    if (!position) return;
    const all: { type: "centre" | "donor"; item: any; distance: number }[] = [];
    centres.forEach((c) => {
      if (c.latitude == null || c.longitude == null) return;
      const d = haversineMeters(position, { latitude: c.latitude, longitude: c.longitude });
      if (d <= 5000) all.push({ type: "centre", item: c, distance: Math.round(d) });
    });
    donors.forEach((d) => {
      if (d.latitude == null || d.longitude == null) return;
      const dist = haversineMeters(position, { latitude: d.latitude, longitude: d.longitude });
      if (dist <= 5000) all.push({ type: "donor", item: d, distance: Math.round(dist) });
    });
    all.sort((a, b) => a.distance - b.distance);
    setNearby(all);
  }, [position, centres, donors]);

  async function runSearch() {
    setSearchResults(null);
    if (!searchGroup) {
      setSearchResults([]);
      return;
    }

    // If position is not available (user denied geolocation), try using map center
    const center = position ?? (mapCenter ? { latitude: mapCenter.latitude, longitude: mapCenter.longitude } : null);
    if (!center) {
      // last resort: return raw centres list without distance
      const fallback = centres.map((c) => ({
        name: c.name,
        phone: c.phone,
        address: c.address,
        latitude: c.latitude,
        longitude: c.longitude,
        units: (c.units as number) ?? 0,
        distance: null,
      }));
      setSearchResults(fallback);
      return;
    }

    try {
      const q = new URLSearchParams({ lat: String(center.latitude), lng: String(center.longitude), group: searchGroup, radiusMeters: "5000" });
      const res = await fetch(`/api/search-by-group?${q.toString()}`);
      if (!res.ok) throw new Error(await res.text());
      const data = await res.json();
      if (Array.isArray(data) && data.length > 0) {
        setSearchResults(data);
      } else {
        // Fallback: compute distances from center using local centres AND donors
        const centerForFallback = center;
        const centreFallback = centres
          .map((c) => {
            const lat = c.latitude ?? c.lat ?? c.location?.latitude;
            const lng = c.longitude ?? c.lng ?? c.location?.longitude;
            if (lat == null || lng == null) return null;
            const d = haversineMeters({ latitude: centerForFallback.latitude, longitude: centerForFallback.longitude }, { latitude: lat, longitude: lng });
            return { id: c._id ?? c.name, type: 'centre', name: c.name, phone: c.phone, address: c.address, latitude: lat, longitude: lng, units: (c.units as number) ?? 0, distance: Math.round(d) };
          })
          .filter(Boolean) as any[];

        const donorFallback = donors
          .map((d) => {
            const lat = d.latitude ?? d.lat;
            const lng = d.longitude ?? d.lng;
            if (lat == null || lng == null) return null;
            const dists = haversineMeters({ latitude: centerForFallback.latitude, longitude: centerForFallback.longitude }, { latitude: lat, longitude: lng });
            return { id: d._id ?? d.email ?? d.name, type: 'donor', name: d.name, phone: d.phone, address: d.address, latitude: lat, longitude: lng, units: 0, distance: Math.round(dists) };
          })
          .filter(Boolean) as any[];

        let allFallback = [...centreFallback, ...donorFallback].sort((a: any, b: any) => a.distance - b.distance);

        // First try within 5km
        let within = allFallback.filter((r) => r.distance <= 5000);
        if (within.length > 0) {
          setSearchResults(within);
          return;
        }

        // If none, expand to 20km
        within = allFallback.filter((r) => r.distance <= 20000);
        if (within.length > 0) {
          setSearchResults(within);
          return;
        }

        // As a last resort return the nearest 5 results regardless of distance
        setSearchResults(allFallback.slice(0, 5));
      }
    } catch (err) {
      console.error("Search error", err);
      // On network error, fallback to computing distances from center using local centres
      if (center) {
        let fallback = centres
          .map((c) => {
            const lat = c.latitude ?? c.lat ?? c.location?.latitude;
            const lng = c.longitude ?? c.lng ?? c.location?.longitude;
            if (lat == null || lng == null) return null;
            const d = haversineMeters({ latitude: center.latitude, longitude: center.longitude }, { latitude: lat, longitude: lng });
            return { name: c.name, phone: c.phone, address: c.address, latitude: lat, longitude: lng, units: (c.units as number) ?? 0, distance: Math.round(d) };
          })
          .filter(Boolean)
          .sort((a: any, b: any) => a.distance - b.distance) as any[];
        const within = fallback.filter((r) => r.distance <= 5000);
        if (within.length > 0) {
          setSearchResults(within as any[]);
        } else {
          setSearchResults([]);
        }
      } else {
        // last resort: nothing within 5km
        setSearchResults([]);
      }
    }
  }

  const points = useMemo(() => {
    const pts: Array<[number, number]> = [];
    if (position) pts.push([position.latitude, position.longitude]);
    nearby.forEach((n) => {
      const lat = n.item.latitude ?? n.item.lat ?? n.item.location?.latitude;
      const lng = n.item.longitude ?? n.item.lng ?? n.item.location?.longitude;
      if (lat && lng) pts.push([lat, lng]);
    });
    return pts;
  }, [position, nearby]);

  return (
    <div className="mx-auto max-w-6xl grid gap-4 lg:grid-cols-2">
      <div className="rounded-lg border overflow-hidden" style={{ height: "60vh" }}>
        <MapContainer center={[20.5937, 78.9629]} zoom={5} style={{ height: "100%", width: "100%" }}>
          <TileLayer url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" attribution="&copy; OpenStreetMap contributors" />

          {/* Component to keep map center in state (used when geolocation denied) */}
          <MapEvents onCenter={handleCenter} />

          {position && (
            <Marker position={[position.latitude, position.longitude]} icon={DefaultMarker}>
              <Popup>You are here</Popup>
            </Marker>
          )}
          {nearby.map((n, idx) => (
            <Marker key={idx} position={[n.item.latitude, n.item.longitude]} icon={DefaultMarker}>
              <Popup>
                <div className="font-semibold">{n.item.name}</div>
                <div className="text-sm text-muted-foreground">{n.item.address}</div>
                <div className="text-xs text-muted-foreground">{n.distance} m away</div>
                <div className="text-xs text-muted-foreground">{n.type === 'donor' ? 'Donor' : 'Centre'}</div>
              </Popup>
            </Marker>
          ))}

          <FitBounds points={points} />
        </MapContainer>
      </div>

      <div>
        <div className="rounded-lg border p-4 bg-white">
          <h2 className="text-lg font-semibold text-red-700">Search Nearby by Blood Group</h2>

          <div className="mt-3 flex gap-2">
            <select
              aria-label="Blood group"
              className="flex-1 rounded-md border border-red-300 px-3 py-2"
              value={searchGroup}
              onChange={(e) => setSearchGroup(e.target.value)}
              id="bb-search-group"
            >
              <option value="">Select group</option>
              {BLOOD_GROUPS.map((g) => (
                <option key={g} value={g}>
                  {g}
                </option>
              ))}
            </select>
            <button onClick={runSearch} id="bb-search-btn" className="rounded-md bg-red-700 px-4 py-2 text-white">
              Search
            </button>
            <button onClick={() => simulateLocation()} className="rounded-md border px-3 py-2 text-sm">Simulate Vijayawada</button>
            <button onClick={() => searchAllGroups()} className="rounded-md border px-3 py-2 text-sm">Search All Groups</button>
          </div>

          <div className="mt-4">
            <h3 className="font-semibold text-green-700">Results (within 5 km)</h3>
            <ul className="mt-3 space-y-3" id="bb-search-results">
              {searchResults === null && <li className="text-sm text-muted-foreground">Searching...</li>}
              {searchResults !== null && searchResults.length === 0 && <li className="text-sm text-muted-foreground">Not available</li>}
              {searchResults !== null && searchResults.length > 0 &&
                searchResults.map((c: any, i: number) => (
                  <li key={i} className="rounded-md border p-3 bg-white">
                    <div className="flex items-start justify-between">
                      <div>
                        <div className="font-semibold text-red-700">{c.name}</div>
                        <div className="text-sm text-muted-foreground">{c.address}</div>
                        <div className="text-xs text-green-700">{c.distance != null ? `${Math.round(c.distance)} m` : 'Distance: N/A'}</div>
                        {c.phone && (
                          <div className="mt-2 flex gap-2">
                            <a className="rounded-md bg-red-700 px-3 py-1 text-sm text-white" href={`tel:${c.phone}`}>
                              Call
                            </a>
                            <a className="rounded-md border px-3 py-1 text-sm" target="_blank" rel="noreferrer" href={`https://www.google.com/maps/dir/?api=1&destination=${c.latitude},${c.longitude}`}>
                              Get Directions
                            </a>
                          </div>
                        )}
                      </div>
                      <div className="text-sm text-muted-foreground">{c.type === 'donor' ? 'Donor' : 'Centre'}</div>
                    </div>
                  </li>
                ))}
            </ul>
          </div>

          <div className="mt-4 rounded-md border p-3 bg-red-50 text-sm text-red-800">
            Tip: Allow location access for accurate results. Calls open your phone dialer.
          </div>
        </div>
      </div>
    </div>
  );
}
