import { useQuery } from "@tanstack/react-query";
import { getDonors, adminGetDonors } from "@/lib/api";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export default function BloodDonors() {
  // Determine whether an admin token is present
  const isAdmin = typeof window !== 'undefined' && !!localStorage.getItem('bb_admin_token');

  const { data } = useQuery({ queryKey: [isAdmin ? 'admin:donors' : 'donors'], queryFn: isAdmin ? adminGetDonors : getDonors });

  return (
    <div className="mx-auto max-w-5xl">
      <Card>
        <CardHeader>
          <CardTitle>Donor Directory</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {(data ?? []).map((d: any) => (
              <div key={d._id ?? d.email ?? d.name} className="rounded-md border p-4 space-y-2">
                <div className="flex items-center justify-between">
                  <div className="font-semibold text-base">{d.name}</div>
                  <div className="rounded bg-primary/10 px-2 py-0.5 text-xs font-medium text-primary">{d.bloodGroup}</div>
                </div>

                <div className="space-y-1 text-xs">
                  {d.city && <div className="text-muted-foreground">{d.city}</div>}

                  {d.age && <div><span className="font-semibold">Age:</span> {d.age}</div>}

                  {d.gender && <div><span className="font-semibold">Gender:</span> {d.gender}</div>}

                  {d.dob && (
                    <div><span className="font-semibold">DOB:</span> {new Date(d.dob).toLocaleDateString()}</div>
                  )}

                  {d.hemoglobin && (
                    <div><span className="font-semibold">Hemoglobin:</span> {d.hemoglobin} g/dL</div>
                  )}

                  {d.diseases && (
                    <div><span className="font-semibold">Conditions:</span> {d.diseases}</div>
                  )}

                  {d.lastDonationDate && (
                    <div className="text-muted-foreground">
                      Last donated: {new Date(d.lastDonationDate).toLocaleDateString()}
                    </div>
                  )}
                </div>

                {/* Show sensitive contact details only to admins */}
                {isAdmin && (
                  <div className="mt-3 pt-3 border-t space-y-1 text-xs">
                    {d.phone && <div><span className="font-semibold">Phone:</span> {d.phone}</div>}
                    {d.email && <div><span className="font-semibold">Email:</span> {d.email}</div>}
                    {d.address && <div><span className="font-semibold">Address:</span> {d.address}</div>}
                    {d.approved !== undefined && (
                      <div><span className="font-semibold">Approved:</span> {String(d.approved)}</div>
                    )}
                  </div>
                )}

                {!isAdmin && (
                  <div className="mt-2 pt-2 border-t text-xs text-muted-foreground">
                    Contact details visible to registered admins only.
                  </div>
                )}
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
