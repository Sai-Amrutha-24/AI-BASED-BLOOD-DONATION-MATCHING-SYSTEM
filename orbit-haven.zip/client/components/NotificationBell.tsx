import { Bell, TriangleAlert } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { getAlerts } from "@/lib/api";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Badge } from "@/components/ui/badge";

export default function NotificationBell() {
  const { data } = useQuery({ queryKey: ["alerts"], queryFn: getAlerts, refetchInterval: 30000 });
  const count = data?.lowStock?.length ?? 0;

  return (
    <Popover>
      <PopoverTrigger className="relative rounded-full p-2 hover:bg-accent" aria-label="Alerts">
        <Bell className="h-5 w-5" />
        {count > 0 && (
          <Badge className="absolute -right-1 -top-1 h-5 min-w-5 rounded-full px-1 bg-destructive text-destructive-foreground">
            {count}
          </Badge>
        )}
      </PopoverTrigger>
      <PopoverContent align="end" className="w-80">
        <div className="space-y-2">
          <div className="flex items-center gap-2 font-semibold">
            <TriangleAlert className="h-4 w-4 text-destructive" /> Low stock alerts
          </div>
          {count === 0 ? (
            <p className="text-sm text-muted-foreground">All blood groups are above the threshold.</p>
          ) : (
            <ul className="space-y-1">
              {data!.lowStock.map((a) => (
                <li key={a.group} className="flex items-center justify-between rounded-md bg-accent/60 p-2">
                  <span className="font-medium">{a.group}</span>
                  <span className="text-sm text-muted-foreground">{a.units} units</span>
                </li>
              ))}
            </ul>
          )}
          <p className="text-xs text-muted-foreground">Threshold: {data?.threshold} units</p>
        </div>
      </PopoverContent>
    </Popover>
  );
}
