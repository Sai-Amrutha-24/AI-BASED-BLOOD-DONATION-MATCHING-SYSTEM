import React from 'react';
import { useLanguage } from '@/hooks/useLanguage';
import { Language } from '@/lib/translations';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Globe } from 'lucide-react';

export default function LanguageSwitcher() {
  const { language, setLanguage } = useLanguage();

  const languages: { code: Language; name: string }[] = [
    { code: 'en', name: 'English' },
    { code: 'te', name: 'తెలుగు (Telugu)' },
    { code: 'hi', name: 'हिन्दी (Hindi)' },
    { code: 'mr', name: 'मराठी (Marathi)' },
    { code: 'kn', name: 'ಕನ್ನಡ (Kannada)' },
    { code: 'ta', name: 'தமிழ் (Tamil)' },
  ];

  return (
    <div className="flex items-center gap-2">
      <span className="text-sm font-medium text-gray-700">Language:</span>
      <Select value={language} onValueChange={(value) => setLanguage(value as Language)}>
        <SelectTrigger className="w-[180px] flex items-center gap-2 border-2 border-gray-300 hover:border-red-500 transition-colors">
          <Globe className="h-4 w-4 text-red-600" />
          <SelectValue placeholder="Select language" />
        </SelectTrigger>
        <SelectContent className="min-w-[220px] max-h-[300px] overflow-y-auto">
          {languages.map((lang) => (
            <SelectItem
              key={lang.code}
              value={lang.code}
              className="py-2 px-3 cursor-pointer hover:bg-red-50"
            >
              <div className="flex items-center gap-2">
                <span className="text-sm font-medium">{lang.name}</span>
              </div>
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
    </div>
  );
}
