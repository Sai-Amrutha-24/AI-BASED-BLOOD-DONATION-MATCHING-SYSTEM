import "./global.css";

import { Toaster } from "@/components/ui/toaster";
import { createRoot } from "react-dom/client";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { LanguageProvider } from "@/hooks/useLanguage";
import RootLayout from "./pages/RootLayout";
import Dashboard from "./pages/Dashboard";
import BloodAvailability from "./pages/BloodAvailability";
import BloodCentres from "./pages/BloodCentres";
import BloodDonors from "./pages/BloodDonors";
import DonationCamps from "./pages/DonationCamps";
import RegisterVolunteer from "./pages/RegisterVolunteer";
import RegisterDonor from "./pages/RegisterDonor";
import Maps from "./pages/Maps";
import AboutUs from "./pages/AboutUs";
import AIDonorMatching from "./pages/AIDonorMatching";
import EmergencyDonorMatching from "./pages/EmergencyDonorMatching";
import AdminDashboard from "./pages/AdminDashboard";
import AdminLogin from "./pages/AdminLogin";
import AdminSignup from "./pages/AdminSignup";
import AdminEmergencyAlert from "./pages/AdminEmergencyAlert";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => (
  <LanguageProvider>
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Sonner />
        <BrowserRouter>
          <Routes>
            <Route element={<RootLayout />}>
              <Route index element={<Dashboard />} />
              <Route path="availability" element={<BloodAvailability />} />
              <Route path="centres" element={<BloodCentres />} />
              <Route path="donors" element={<BloodDonors />} />
              <Route path="camps" element={<DonationCamps />} />
              <Route path="register" element={<RegisterVolunteer />} />
              <Route path="donor-register" element={<RegisterDonor />} />
              <Route path="maps" element={<Maps />} />
              <Route path="about" element={<AboutUs />} />
              <Route path="ai-matching" element={<AIDonorMatching />} />
              <Route path="emergency-matching" element={<EmergencyDonorMatching />} />
              <Route path="admin/login" element={<AdminLogin />} />
              <Route path="admin/signup" element={<AdminSignup />} />
              <Route path="admin" element={<AdminDashboard />} />
              <Route path="admin/emergency-alert" element={<AdminEmergencyAlert />} />
              <Route path="*" element={<NotFound />} />
            </Route>
          </Routes>
        </BrowserRouter>
      </TooltipProvider>
    </QueryClientProvider>
  </LanguageProvider>
);

createRoot(document.getElementById("root")!).render(<App />);
