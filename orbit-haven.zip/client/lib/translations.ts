export type Language = 'en' | 'te' | 'hi' | 'mr' | 'kn' | 'ta';

export const translations = {
  en: {
    // Navigation
    home: 'Home',
    bloodAvailability: 'Blood Availability',
    bloodCentres: 'Blood Centres',
    camps: 'Donation Camps',
    registerVolunteer: 'Register Volunteer',
    registerDonor: 'Register Donor',
    maps: 'Maps',
    aboutUs: 'About Us',
    admin: 'Admin',
    becomeVolunteer: 'Become a Volunteer',
    bloodBankManagement: 'Blood Bank Management',

    // Dashboard
    donateBlood: 'Donate Blood',
    saveLives: 'Donate Blood. Save Lives.',
    joinCommunity: 'Join our community of donors and help patients in need. Find available blood, register as a donor, or volunteer at nearby camps.',
    findBlood: 'Find Blood',
    availableUnitsToday: 'Available Units Today',

    // AI Donor Matching
    aiDonorMatching: 'AI-Based Blood Donation & Matching System',
    emergencyMatching: 'Emergency Matching',
    aiMatchingDesc: 'Our intelligent system finds nearby eligible donors based on blood group, location, availability, and last donation date.',
    findingDonors: 'Finding best donors near you…',
    donorName: 'Donor Name',
    bloodGroup: 'Blood Group',
    distance: 'Distance',
    availability: 'Availability',
    lastDonationDate: 'Last Donation Date',
    contactNow: 'Contact Now',
    available: 'Available',
    notAvailable: 'Not Available',
    aiPoweredMatching: 'AI Powered Matching',
    noDonorsFound: 'No eligible donors found in your area',

    // Language
    language: 'Language',

    // Admin
    adminDashboard: 'Admin Dashboard',
    donorRegistrations: 'Donor Registrations',
    bloodCentres: 'Blood Centres',
    donationCamps: 'Donation Camps',
    volunteers: 'Volunteers',
    approve: 'Approve',
    reject: 'Reject',
    logout: 'Logout',
    sendEmergencyAlert: 'Send Emergency Alert',
    noDonorsFoundMsg: 'No donors found',
    noCentresFound: 'No centres found',
    noCampsFound: 'No camps found',
    noVolunteersFound: 'No volunteers found',

    // Common
    loading: 'Loading...',
    error: 'Error',
    success: 'Success',
    cancel: 'Cancel',
    save: 'Save',
    delete: 'Delete',
  },
  te: {
    // Navigation
    home: 'హోమ్',
    bloodAvailability: 'రక్తం అందుబాటులో ఉంది',
    bloodCentres: 'రక్త కేంద్రాలు',
    camps: 'రక్తదాన శిబిరాలు',
    registerVolunteer: 'స్వచ్ఛందसేవకుడిగా నమోదు చేయండి',
    registerDonor: 'దాతగా నమోదు చేయండి',
    maps: 'మ్యాప్‌లు',
    aboutUs: 'మా గురించి',
    admin: 'నిర్వాహకుడు',
    becomeVolunteer: 'స్వచ్ఛందసేవకుడిగా మారండి',
    bloodBankManagement: 'రక్త బ్యాంకు నిర్వహణ',

    // Dashboard
    donateBlood: 'రక్తదానం చేయండి',
    saveLives: 'రక్తదానం చేయండి. జీవితాలను కాపాడండి.',
    joinCommunity: 'మా దాతల సম్ప్రదాయానికి చేరండి మరియు సమస్యలో ఉన్న రోగులకు సహాయం చేయండి. అందుబాటులో ఉన్న రక్తాన్ని కనుగొనండి, దాతగా నమోదు చేయండి లేదా సమీప శిబిరాలలో స్వచ్ఛందసేవ చేయండి.',
    findBlood: 'రక్తాన్ని కనుగొనండి',
    availableUnitsToday: 'ఈ రోజు అందుబాటులో ఉన్న యూనిట్‌లు',

    // AI Donor Matching
    aiDonorMatching: 'ఎআई-ఆధారిత అత్యవసర దాత సరిపోలిక',
    aiMatchingDesc: 'మా ఇంటెలిజెంట్ సిస్టమ్ రక్త సమూహం, ఆయురోగ్యం, అందుబాటులో ఉంటుంది మరియు చివరిసారి రక్తదానం చేసిన తేదీ ఆధారంగా సమీప అర్హత కలిగిన దాతలను కనుగొంటుంది.',
    findingDonors: 'మీ సమీపంలో ఉత్తమ దాతలను కనుగొంటున్నాము…',
    donorName: 'దాత పేరు',
    bloodGroup: 'రక్త సమూహం',
    distance: 'దూరం',
    availability: 'అందుబాటులో ఉంటుంది',
    lastDonationDate: 'చివరిసారి రక్తదానం చేసిన తేదీ',
    contactNow: 'ఇప్పుడు సంప్రదించండి',
    available: 'అందుబాటులో ఉంది',
    notAvailable: 'అందుబాటులో లేదు',
    aiPoweredMatching: 'ఎআই ఆధారిత సరిపోలిక',
    noDonorsFound: 'మీ ప్రాంతంలో అర్హత కలిగిన దాతలు కనుగొనబడలేదు',

    // Language
    language: 'భాష',

    // Admin
    adminDashboard: 'నిర్వాహకుడు డ్యాష్‌బోర్డ్',
    donorRegistrations: 'దాత నమోదులు',
    bloodCentres: 'రక్త కేంద్రాలు',
    donationCamps: 'రక్తదాన శిబిరాలు',
    volunteers: 'స్వచ్ఛందసేవకులు',
    approve: 'ఆమోదించండి',
    reject: 'తిరస్కరించండి',
    logout: 'లాగ్ అవుట్',
    sendEmergencyAlert: 'అత్యవసర అలర్ట్ పంపండి',
    noDonorsFoundMsg: 'దాతలు కనుగొనబడలేదు',
    noCentresFound: 'కేంద్రాలు కనుగొనబడలేదు',
    noCampsFound: 'శిబిరాలు కనుగొనబడలేదు',
    noVolunteersFound: 'స్వచ్ఛందసేవకులు కనుగొనబడలేదు',

    // Common
    loading: 'లోడ్ చేస్తున్నాము...',
    error: 'లోపం',
    success: 'విజయం',
    cancel: 'రద్దు చేయండి',
    save: 'సేవ్ చేయండి',
    delete: 'తొలగించండి',
  },
  hi: {
    // Navigation
    home: 'होम',
    bloodAvailability: 'रक्त उपलब्धता',
    bloodCentres: 'रक्त केंद्र',
    camps: 'रक्तदान शिविर',
    registerVolunteer: 'स्वयंसेवक के रूप में पंजीकरण करें',
    registerDonor: 'दाता के रूप में पंजीकरण करें',
    maps: 'नक्शे',
    aboutUs: 'हमारे बारे में',
    admin: 'प्रशासक',
    becomeVolunteer: 'एक स्वयंसेवक बनें',
    bloodBankManagement: 'रक्त बैंक प्रबंधन',

    // Dashboard
    donateBlood: 'रक्त दान करें',
    saveLives: 'रक्त दान करें। जीवन बचाएं।',
    joinCommunity: 'हमारे दाताओं के समुदाय में शामिल हों और जरूरतमंद रोगियों की मदद करें। उपलब्ध रक्त खोजें, दाता के रूप में पंजीकरण करें या पास के शिविरों में स्वयंसेवा करें।',
    findBlood: 'रक्त खोजें',
    availableUnitsToday: 'आज उपलब्ध इकाइयाँ',

    // AI Donor Matching
    aiDonorMatching: 'कृत्रिम बुद्धिमत्ता संचालित आपातकालीन दाता मिलान',
    aiMatchingDesc: 'हमारी बुद्धिमान प्रणाली रक्त समूह, स्थान, उपलब्धता और अंतिम दान की तारीख के आधार पर पास के योग्य दाताओं को खोजती है।',
    findingDonors: 'आपके पास सर्वोत्तम दाता खोज रहे हैं…',
    donorName: 'दाता का नाम',
    bloodGroup: 'रक्त समूह',
    distance: 'दूरी',
    availability: 'उपलब्धता',
    lastDonationDate: 'अंतिम दान की तारीख',
    contactNow: 'अभी संपर्क करें',
    available: 'उपलब्ध',
    notAvailable: 'उपलब्ध नहीं',
    aiPoweredMatching: 'कृत्रिम बुद्धिमत्ता संचालित मिलान',
    noDonorsFound: 'आपके क्षेत्र में कोई योग्य दाता नहीं मिले',

    // Language
    language: 'भाषा',

    // Admin
    adminDashboard: 'प्रशासक डैशबोर्ड',
    donorRegistrations: 'दाता पंजीकरण',
    bloodCentres: 'रक्त केंद्र',
    donationCamps: 'रक्तदान शिविर',
    volunteers: 'स्वयंसेवक',
    approve: 'स्वीकृति दें',
    reject: 'अस्वीकार करें',
    logout: 'लॉगआउट',
    sendEmergencyAlert: 'आपातकालीन अलर्ट भेजें',
    noDonorsFoundMsg: 'कोई दाता नहीं मिला',
    noCentresFound: 'कोई केंद्र नहीं मिला',
    noCampsFound: 'कोई शिविर नहीं मिला',
    noVolunteersFound: 'कोई स्वयंसेवक नहीं मिला',

    // Common
    loading: 'लोड हो रहा है...',
    error: 'त्रुटि',
    success: 'सफल',
    cancel: 'रद्द करें',
    save: 'सहेजें',
    delete: 'हटाएं',
  },
  mr: {
    // Navigation (Marathi)
    home: 'मुख्यपृष्ठ',
    bloodAvailability: 'रक्ताची उपलब्धता',
    bloodCentres: 'रक्त केंद्रे',
    camps: 'रक्तदान शिबिरे',
    registerVolunteer: 'स्वयंसेवक म्हणून नोंदणी करा',
    registerDonor: 'दान करणारा म्हणून नोंदणी करा',
    maps: 'नकाशे',
    aboutUs: 'आमच्या बद्दल',
    admin: 'प्रशासक',
    becomeVolunteer: 'स्वयंसेवक व्हा',
    bloodBankManagement: 'रक्त बँक व्यवस्थापन',

    // Dashboard
    donateBlood: 'रक्त दान करा',
    saveLives: 'रक्त दान करा। जीवन वाचवा।',
    joinCommunity: 'आमच्या दान करणाऱ्यांच्या समुदायात सामील व्हा आणि जरूरतीच्या रोगींना मदत करा। उपलब्ध रक्त शोधा, दान करणारा म्हणून नोंदणी करा किंवा जवळपास शिबिरांमध्ये स्वयंसेवा करा।',
    findBlood: 'रक्त शोधा',
    availableUnitsToday: 'आज उपलब्ध युनिट्स',

    // AI Donor Matching
    aiDonorMatching: 'कृत्रिम बुद्धिमत्ता संचालित आपातकालीन दान करणारा जुळणी',
    aiMatchingDesc: 'आमची बुद्धिमान प्रणाली रक्त प्रकार, स्थान, उपलब्धता आणि शेवटच्या दान तारखेच्या आधारे जवळच्या योग्य दान करणाऱ्यांना शोधते।',
    findingDonors: 'आपल्या जवळ सर्वोत्तम दान करणारे शोधत आहे…',
    donorName: 'दान करणाऱ्याचे नाव',
    bloodGroup: 'रक्त प्रकार',
    distance: 'अंतर',
    availability: 'उपलब्धता',
    lastDonationDate: 'शेवटची दान तारीख',
    contactNow: 'आता संपर्क करा',
    available: 'उपलब्ध',
    notAvailable: 'उपलब्ध नाही',
    aiPoweredMatching: 'कृत्रिम बुद्धिमत्ता संचालित जुळणी',
    noDonorsFound: 'आपल्या क्षेत्रात कोणते योग्य दान करणारे सापडले नाहीत',

    // Language
    language: 'भाषा',

    // Admin
    adminDashboard: 'प्रशासक डॅशबोर्ड',
    donorRegistrations: 'दान करणारांची नोंदणी',
    donationCamps: 'रक्तदान शिबिरे',
    volunteers: 'स्वयंसेवक',
    approve: 'मंजूर करा',
    reject: 'नाकारा',
    logout: 'लॉग आउट',
    sendEmergencyAlert: 'आपातकालीन सतर्कता पाठवा',
    noDonorsFoundMsg: 'कोणते दान करणारे सापडले नाहीत',
    noCentresFound: 'कोणती केंद्रे सापडली नाहीत',
    noCampsFound: 'कोणती शिबिरे सापडली नाहीत',
    noVolunteersFound: 'कोणते स्वयंसेवक सापडले नाहीत',

    // Common
    loading: 'लोड होत आहे...',
    error: 'त्रुटी',
    success: 'यशस्वी',
    cancel: 'रद्द करा',
    save: 'जतन करा',
    delete: 'हटवा',
  },
  kn: {
    // Navigation (Kannada)
    home: 'ಮುಖ್ಯ ಪುಟ',
    bloodAvailability: 'ರಕ್ತ ಲಭ್ಯತೆ',
    bloodCentres: 'ರಕ್ತ ಕೇಂದ್ರಗಳು',
    camps: 'ರಕ್ತದಾನ ಶಿಬಿರಗಳು',
    registerVolunteer: 'ಸ್ವಯಂಸೇವಕನಾಗಿ ನೋಂದಾಯಿಸಿ',
    registerDonor: 'ದಾನಕಾರನಾಗಿ ನೋಂದಾಯಿಸಿ',
    maps: 'ನಕ್ಷೆಗಳು',
    aboutUs: 'ನಮ್ಮ ಬಗ್ಗೆ',
    admin: 'ನಿರ್ವಾಹಕ',
    becomeVolunteer: 'ಸ್ವಯಂಸೇವಕನಾಗಿ ಬನ್ನಿ',
    bloodBankManagement: 'ರಕ್ತ ಬ್ಯಾಂಕ್ ನಿರ್ವಹಣೆ',

    // Dashboard
    donateBlood: 'ರಕ್ತ ದಾನ ಮಾಡಿ',
    saveLives: 'ರಕ್ತ ದಾನ ಮಾಡಿ. ಜೀವನ ರಕ್ಷಿಸಿ.',
    joinCommunity: 'ನಮ್ಮ ದಾನಕಾರರ ಸಮುದಾಯದಲ್ಲಿ ಸೇರಿ ಅಗತ್ಯವಿರುವ ರೋಗಿಗಳಿಗೆ ಸಹಾಯ ಮಾಡಿ. ಲಭ್ಯವಿರುವ ರಕ್ತ ಹುಡುಕಿ, ದಾನಕಾರನಾಗಿ ನೋಂದಾಯಿಸಿ ಅಥವಾ ಹತ್ತಿರದ ಶಿಬಿರಗಳಲ್ಲಿ ಸ್ವಯಂಸೇವಾ ಕಾರ್ಯ ಮಾಡಿ.',
    findBlood: 'ರಕ್ತ ಹುಡುಕಿ',
    availableUnitsToday: 'ಇಂದು ಲಭ್ಯವಿರುವ ಘಟಕಗಳು',

    // AI Donor Matching
    aiDonorMatching: 'ಕೃತ್ರಿಮ ಬುದ್ಧಿಮತ್ತೆ ಚಾಲಿತ ತುರ್ತು ದಾನಕಾರ ಹೊಂದಾಣಿಕೆ',
    aiMatchingDesc: 'ನಮ್ಮ ಬುದ್ಧಿಮಾನ ವ್ಯವಸ್ಥೆ ರಕ್ತ ಪ್ರಕಾರ, ಸ್ಥಾನ, ಲಭ್ಯತೆ ಮತ್ತು ಕೊನೆಯ ದಾನದ ದಿನಾಂಕದ ಆಧಾರದ ಮೇಲೆ ಹತ್ತಿರದ ಯೋಗ್ಯ ದಾನಕಾರರನ್ನು ಕಂಡುಕಳುಹುತ್ತದೆ.',
    findingDonors: 'ನಿಮ್ಮ ಸಮೀಪದಲ್ಲಿ ಉತ್ತಮ ದಾನಕಾರರನ್ನು ಹುಡುಕುತ್ತಿರುವೆ…',
    donorName: 'ದಾನಕಾರನ ಹೆಸರು',
    bloodGroup: 'ರಕ್ತ ಪ್ರಕಾರ',
    distance: 'ದೂರ',
    availability: 'ಲಭ್ಯತೆ',
    lastDonationDate: 'ಕೊನೆಯ ದಾನದ ದಿನಾಂಕ',
    contactNow: 'ಈಗ ಸಂಪರ್ಕ ಮಾಡಿ',
    available: 'ಲಭ್ಯ',
    notAvailable: 'ಲಭ್ಯವಿಲ್ಲ',
    aiPoweredMatching: 'ಕೃತ್ರಿಮ ಬುದ್ಧಿಮತ್ತೆ ಚಾಲಿತ ಹೊಂದಾಣಿಕೆ',
    noDonorsFound: 'ನಿಮ್ಮ ಪ್ರದೇಶದಲ್ಲಿ ಯೋಗ್ಯ ದಾನಕಾರರು ಸಿಕ್ಕಿಲ್ಲ',

    // Language
    language: 'ಭಾಷೆ',

    // Admin
    adminDashboard: 'ನಿರ್ವಾಹಕ ನೆರುಳುಮಂಚ',
    donorRegistrations: 'ದಾನಕಾರ ನೋಂದಣಿಗಳು',
    donationCamps: 'ರಕ್ತದಾನ ಶಿಬಿರಗಳು',
    volunteers: 'ಸ್ವಯಂಸೇವಕರು',
    approve: 'ಅನುಮೋದಿಸಿ',
    reject: 'ತಿರಸ್ಕರಿಸಿ',
    logout: 'ಲಾಗ್ ಔಟ್',
    sendEmergencyAlert: 'ತುರ್ತು ಎಚ್ಚರಿಕೆ ಕಳುಹಿಸಿ',
    noDonorsFoundMsg: 'ದಾನಕಾರರು ಸಿಕ್ಕಿಲ್ಲ',
    noCentresFound: 'ಕೇಂದ್ರಗಳು ಸಿಕ್ಕಿಲ್ಲ',
    noCampsFound: 'ಶಿಬಿರಗಳು ಸಿಕ್ಕಿಲ್ಲ',
    noVolunteersFound: 'ಸ್ವಯಂಸೇವಕರು ಸಿಕ್ಕಿಲ್ಲ',

    // Common
    loading: 'ಲೋಡ್ ಆಗುತ್ತಿದೆ...',
    error: 'ದೋಷ',
    success: 'ಸಫಲ',
    cancel: 'ರದ್ದುಗೊಳಿಸಿ',
    save: 'ಉಳಿಸಿ',
    delete: 'ಅಳಿಸಿ',
  },
  ta: {
    // Navigation (Tamil)
    home: 'முகப்பு',
    bloodAvailability: 'இரத்த கிடைக்கும் தன்மை',
    bloodCentres: 'இரத்த மையங்கள்',
    camps: 'இரத்த தான முகாம்',
    registerVolunteer: 'தன்னார்வலராக பதிவு செய்',
    registerDonor: 'இரத்த தான செய்பவராக பதிவு செய்',
    maps: 'வரைபடங்கள்',
    aboutUs: 'எங்களைப் பற்றி',
    admin: 'நிர்வாகி',
    becomeVolunteer: 'தன்னார்வலர் ஆ',
    bloodBankManagement: 'இரத்த வங்கி நிர்வாகம்',

    // Dashboard
    donateBlood: 'இரத்த தான செய்',
    saveLives: 'இரத்த தான செய். உயிரைக் காப்பாற்றுங்கள்.',
    joinCommunity: 'எங்கள் இரத்த தாதாக்களின் சமூகத்தில் சேர்ந்து தேவைப்படும் நோயாளிகளுக்கு உதவுங்கள். கிடைக்கும் இரத்தத்தை கண்டறியுங்கள், இரத்த தான செய்பவராக பதிவு செய்யுங்கள் அல்லது அருகில் உள்ள முகாம்களில் தன்னார்வல சேவை செய்யுங்கள்.',
    findBlood: 'இரத்தத்தை கண்டறியுங்கள்',
    availableUnitsToday: 'இன்று கிடைக்கும் அலகுகள்',

    // AI Donor Matching
    aiDonorMatching: 'கட்டை ஆற்றல் உள் இரத்த தாதா பொருத்தம்',
    aiMatchingDesc: 'எங்கள் புத்திசாலி கணினியமைப்பு இரத்த வகை, இருப்பிடம், கிடைக்கும் தன்மை மற்றும் கடைசி இரத்த தான தேதி ஆகியவற்றின் அடிப்படையில் அருகில் உள்ள தகுதி வாய்ந்த இரத்த தாதாக்களைக் கண்டறியும்.',
    findingDonors: 'உங்கள் அருகாமையில் சிறந்த இரத்த தாதாக்களை தேடுகிறோம்...',
    donorName: 'இரத்த தாதாவின் பெயர்',
    bloodGroup: 'இரத்த வகை',
    distance: 'தூரம்',
    availability: 'கிடைக்கும் தன்மை',
    lastDonationDate: 'கடைசி இரத்த தான தேதி',
    contactNow: 'இப்போது தொடர்பு கொள்ளுங்கள்',
    available: 'கிடைக்கப்பட்டுள்ளது',
    notAvailable: 'கிடைக்கவில்லை',
    aiPoweredMatching: 'கட்டை ஆற்றல் பொருத்தம்',
    noDonorsFound: 'உங்கள் பகுதியில் தகுதி வாய்ந்த இரத்த தாதாக்கள் கண்டறியப்படவில்லை',

    // Language
    language: 'மொழி',

    // Admin
    adminDashboard: 'நிர்வாகி பலகை',
    donorRegistrations: 'இரத்த தாதா பதிவுகள்',
    donationCamps: 'இரத்த தான முகாம்',
    volunteers: 'தன்னார்வலர்கள்',
    approve: 'ஒப்புக் கொள்ளுங்கள்',
    reject: 'நிராகரிக்கவும்',
    logout: 'வெளியேறு',
    sendEmergencyAlert: 'விபத்து எச்சரிக்கை அனுப்பவும்',
    noDonorsFoundMsg: 'இரத்த தாதாக்கள் கண்டறியப்படவில்லை',
    noCentresFound: 'மையங்கள் கண்டறியப்படவில்லை',
    noCampsFound: 'முகாம்கள் கண்டறியப்படவில்லை',
    noVolunteersFound: 'தன்னார்வலர்கள் கண்டறியப்படவில்லை',

    // Common
    loading: 'ஏற்றப்படுகிறது...',
    error: 'பிழை',
    success: 'வெற்றி',
    cancel: 'ரத்து செய்',
    save: 'சேமிக்கவும்',
    delete: 'நீக்கவும்',
  },
} as const;

export type TranslationKey = keyof typeof translations.en;
