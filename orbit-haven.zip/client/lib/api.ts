export type BloodGroup = "A+"|"A-"|"B+"|"B-"|"AB+"|"AB-"|"O+"|"O-";

export interface StockItem { group: BloodGroup; units: number; centreId?: string }
export interface Centre { _id?: string; name: string; address: string; city?: string; state?: string; phone?: string; latitude?: number; longitude?: number }
export interface Donor { _id?: string; name: string; age?: number; gender?: string; bloodGroup: BloodGroup; lastDonationDate?: string; phone?: string; city?: string }
export interface Camp { _id?: string; name: string; date: string; address?: string; latitude?: number; longitude?: number }
export interface Volunteer { _id?: string; name: string; email?: string; phone?: string; city?: string; interests?: string }

export interface Stats { totalUnits: number; totalDonors: number; totalCentres: number; upcomingCamps: number; lowStock: { group: BloodGroup; units: number }[] }
export interface Alerts { lowStock: { group: BloodGroup; units: number }[]; threshold: number }

async function api<T>(path: string, init?: RequestInit): Promise<T> {
  const norm = (p: string) => p.startsWith("/") ? p : `/${p}`;

  // Build candidate URLs to try in order, covering dev server, absolute origin, netlify serverless wrapper, and plain /api
  const candidates = [] as string[];

  // 1. Relative path (e.g. /api/stats)
  candidates.push(norm(path));

  // 2. Absolute origin + path (helps when base path differs)
  if (typeof window !== "undefined" && window.location?.origin) {
    candidates.push(`${window.location.origin}${norm(path)}`);
  }

  // 3. Netlify wrapper: /.netlify/functions/api + (path with leading /api removed)
  const stripped = norm(path).replace(/^\/api/, "");
  candidates.push(`/.netlify/functions/api${stripped}`);
  if (typeof window !== "undefined" && window.location?.origin) {
    candidates.push(`${window.location.origin}/.netlify/functions/api${stripped}`);
  }

  // 4. Fallback ensure /api prefix
  candidates.push(`/api${norm(path)}`);

  let lastErr: any = null;

  // attach Authorization header if admin token present
  const token = typeof window !== 'undefined' ? localStorage.getItem('bb_admin_token') : null;

  for (const url of candidates) {
    try {
      // Helpful debug output in browser console
      // eslint-disable-next-line no-console
      console.debug("api: attempting", url, init?.method ?? "GET");

      // Only set Content-Type for requests that have a body / non-GET to avoid unnecessary preflight CORS requests
      const headers: Record<string,string> = {};
      const method = (init && (init as any).method) ? (init as any).method.toUpperCase() : 'GET';
      if (init?.body || method !== 'GET') headers['Content-Type'] = 'application/json';
      if (token) headers['Authorization'] = `Bearer ${token}`;
      let res: Response;
      try {
        res = await fetch(url, { headers, ...init });
      } catch (fetchErr: any) {
        // Network-level error (DNS, blocked, CORS preflight failure etc.)
        const err = new Error(`Network request failed for ${url}: ${fetchErr?.message || fetchErr}`);
        // eslint-disable-next-line no-console
        console.warn(err);
        lastErr = err;
        continue;
      }
      if (!res.ok) {
        const text = await res.text().catch(() => "");
        const err = new Error(`Request failed (${url}): ${res.status} ${res.statusText} ${text}`);
        // eslint-disable-next-line no-console
        console.warn(err);
        lastErr = err;
        continue;
      }

      return (await res.json()) as T;
    } catch (err: any) {
      // Network/other errors — record and continue with next candidate
      // eslint-disable-next-line no-console
      console.warn("api: request error", url, err?.message ?? err);
      lastErr = err;
      continue;
    }
  }

  // If we get here, all attempts failed — throw a descriptive error
  throw new Error(`All API fetch attempts failed for ${path}. Last error: ${lastErr?.message ?? String(lastErr)}`);
}

export const getStats = () => api<Stats>("/api/stats");
export const getStocks = () => api<StockItem[]>("/api/stocks");
export const getCentres = () => api<Centre[]>("/api/centres");
export const getDonors = () => api<Donor[]>("/api/donors");
export const getCamps = () => api<Camp[]>("/api/camps");
export const postVolunteer = (v: Volunteer) => api<Volunteer>("/api/volunteers", { method: "POST", body: JSON.stringify(v) });
export const postDonor = (d: Partial<Donor>) => api<Donor>("/api/donors", { method: "POST", body: JSON.stringify(d) });

// Safe wrapper for alerts - return empty when network fails
export const getAlerts = async () => {
  try {
    return await api<Alerts>("/api/alerts");
  } catch (e) {
    // eslint-disable-next-line no-console
    console.warn('getAlerts failed, returning fallback', e);
    return { lowStock: [], threshold: 20 } as Alerts;
  }
};

// Admin helpers with graceful fallbacks so UI doesn't break if server unreachable
export const adminGetDonors = async () => {
  try {
    return await api<any[]>("/api/admin/donors");
  } catch (e) {
    // eslint-disable-next-line no-console
    console.warn('adminGetDonors failed', e);
    return [] as any[];
  }
};
export const adminApproveDonor = async (id: string) => {
  try {
    return await api<any>(`/api/admin/donors/${id}/approve`, { method: "PATCH" });
  } catch (e) {
    // eslint-disable-next-line no-console
    console.warn('adminApproveDonor failed', e);
    throw e;
  }
};
export const adminRejectDonor = async (id: string) => {
  try {
    return await api<any>(`/api/admin/donors/${id}/reject`, { method: "PATCH" });
  } catch (e) {
    // eslint-disable-next-line no-console
    console.warn('adminRejectDonor failed', e);
    throw e;
  }
};

export const adminNotifyDonor = async (id: string, payload: { method: 'sms' | 'email'; message: string }) => {
  try {
    return await api<any>(`/api/admin/donors/${id}/notify`, { method: 'POST', body: JSON.stringify(payload) });
  } catch (e) {
    // eslint-disable-next-line no-console
    console.warn('adminNotifyDonor failed', e);
    throw e;
  }
};

export const adminSendEmergencyAlert = async (payload: { bloodGroup: string; city?: string; contactNumber: string; customMessage?: string; method: 'sms' | 'email' }) => {
  try {
    return await api<any>('/api/admin/emergency-alert', { method: 'POST', body: JSON.stringify(payload) });
  } catch (e) {
    // eslint-disable-next-line no-console
    console.warn('adminSendEmergencyAlert failed', e);
    throw e;
  }
};

export const adminGetCentres = async () => {
  try {
    return await api<any[]>("/api/admin/centres");
  } catch (e) {
    // eslint-disable-next-line no-console
    console.warn('adminGetCentres failed', e);
    return [] as any[];
  }
};
export const adminApproveCentre = async (id: string) => {
  try {
    return await api<any>(`/api/admin/centres/${id}/approve`, { method: "PATCH" });
  } catch (e) {
    // eslint-disable-next-line no-console
    console.warn('adminApproveCentre failed', e);
    throw e;
  }
};
export const adminRejectCentre = async (id: string) => {
  try {
    return await api<any>(`/api/admin/centres/${id}/reject`, { method: "PATCH" });
  } catch (e) {
    // eslint-disable-next-line no-console
    console.warn('adminRejectCentre failed', e);
    throw e;
  }
};

export const adminGetCamps = async () => {
  try {
    return await api<any[]>("/api/admin/camps");
  } catch (e) {
    // eslint-disable-next-line no-console
    console.warn('adminGetCamps failed', e);
    return [] as any[];
  }
};

export const adminGetVolunteers = async () => {
  try {
    return await api<any[]>("/api/admin/volunteers");
  } catch (e) {
    // eslint-disable-next-line no-console
    console.warn('adminGetVolunteers failed', e);
    return [] as any[];
  }
};

export const adminDeleteVolunteer = async (id: string) => {
  try {
    return await api<any>(`/api/admin/volunteers/${id}`, { method: 'DELETE' });
  } catch (e) {
    // eslint-disable-next-line no-console
    console.warn('adminDeleteVolunteer failed', e);
    throw e;
  }
};
export const adminApproveCamp = async (id: string) => {
  try {
    return await api<any>(`/api/admin/camps/${id}/approve`, { method: "PATCH" });
  } catch (e) {
    // eslint-disable-next-line no-console
    console.warn('adminApproveCamp failed', e);
    throw e;
  }
};
export const adminRejectCamp = async (id: string) => {
  try {
    return await api<any>(`/api/admin/camps/${id}/reject`, { method: "PATCH" });
  } catch (e) {
    // eslint-disable-next-line no-console
    console.warn('adminRejectCamp failed', e);
    throw e;
  }
};

// Admin auth + management
export const adminLogin = (payload: { email: string; password: string }) => api<any>("/api/admin/login", { method: "POST", body: JSON.stringify(payload) });
export const adminSignup = (payload: { name: string; email: string; password: string; hospitalId?: string }) => api<any>("/api/admin/signup", { method: "POST", body: JSON.stringify(payload) });
export const adminList = () => api<any[]>("/api/admins");
export const adminDelete = (id: string) => api<any>(`/api/admins/${id}`, { method: 'DELETE' });
