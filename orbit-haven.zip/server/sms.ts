// Twilio SMS Service
let twilioClient: any = null;

export async function initTwilio() {
  const accountSid = process.env.TWILIO_ACCOUNT_SID;
  const authToken = process.env.TWILIO_AUTH_TOKEN;

  if (!accountSid || !authToken) {
    // eslint-disable-next-line no-console
    console.warn('Twilio credentials not configured. SMS delivery disabled.');
    return null;
  }

  try {
    const twilio = await import('twilio');
    twilioClient = twilio.default(accountSid, authToken);
    // eslint-disable-next-line no-console
    console.info('Twilio client initialized successfully');
    return twilioClient;
  } catch (error: any) {
    // eslint-disable-next-line no-console
    console.error('Failed to initialize Twilio:', error?.message);
    return null;
  }
}

export async function sendSMS(to: string, message: string): Promise<boolean> {
  try {
    if (!twilioClient) {
      twilioClient = await initTwilio();
      if (!twilioClient) {
        // eslint-disable-next-line no-console
        console.warn('Cannot send SMS: Twilio not configured');
        return false;
      }
    }

    const fromNumber = process.env.TWILIO_PHONE_NUMBER;
    if (!fromNumber) {
      // eslint-disable-next-line no-console
      console.warn('TWILIO_PHONE_NUMBER not configured');
      return false;
    }

    const result = await twilioClient.messages.create({
      body: message,
      from: fromNumber,
      to: to,
    });

    // eslint-disable-next-line no-console
    console.info('SMS sent successfully:', { to, messageId: result.sid });
    return true;
  } catch (error: any) {
    // eslint-disable-next-line no-console
    console.error('Failed to send SMS:', { to, error: error?.message });
    return false;
  }
}

export async function sendBulkSMS(recipients: string[], message: string): Promise<{ sent: number; failed: number }> {
  let sent = 0;
  let failed = 0;

  for (const phone of recipients) {
    const success = await sendSMS(phone, message);
    if (success) sent++;
    else failed++;
  }

  return { sent, failed };
}
