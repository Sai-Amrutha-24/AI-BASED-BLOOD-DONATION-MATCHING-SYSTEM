import mongoose, { Schema, model } from "mongoose";

export const BLOOD_GROUPS = ["A+","A-","B+","B-","AB+","AB-","O+","O-"] as const;
export type BloodGroup = typeof BLOOD_GROUPS[number];

const uri = process.env.MONGODB_URI;

export const models = {
  Centre: mongoose.models.Centre || model("Centre", new Schema({
    name: String,
    address: String,
    city: String,
    state: String,
    phone: String,
    latitude: Number,
    longitude: Number,
  }, { timestamps: true })),
  Donor: mongoose.models.Donor || model("Donor", new Schema({
    name: String,
    age: Number,
    gender: String,
    bloodGroup: { type: String, enum: BLOOD_GROUPS },
    lastDonationDate: Date,
    phone: String,
    city: String,
    email: String,
    dob: Date,
    hemoglobin: Number,
    diseases: String,
    address: String,
    latitude: Number,
    longitude: Number,
    hospitalId: String,
    approved: { type: Boolean, default: false },
  }, { timestamps: true })),
  Stock: mongoose.models.Stock || model("Stock", new Schema({
    group: { type: String, enum: BLOOD_GROUPS },
    units: Number,
    centreId: { type: Schema.Types.ObjectId, ref: "Centre" },
  }, { timestamps: true })),
  Admin: mongoose.models.Admin || model("Admin", new Schema({
    name: String,
    email: String,
    password: String, // stored as plain for fallback memory mode; recommend hashing in production
    role: String,
    hospitalId: String,
  }, { timestamps: true })),
  Camp: mongoose.models.Camp || model("Camp", new Schema({
    name: String,
    date: Date,
    address: String,
    latitude: Number,
    longitude: Number,
  }, { timestamps: true })),
  Volunteer: mongoose.models.Volunteer || model("Volunteer", new Schema({
    name: String,
    email: String,
    phone: String,
    city: String,
    interests: String,
  }, { timestamps: true })),
};

let connected = false;
export async function connectMongo() {
  if (!uri) return false;
  if (connected) return true;
  try {
    await mongoose.connect(uri, { dbName: process.env.MONGODB_DB || undefined });
    connected = true;
    return true;
  } catch (e) {
    console.error("Mongo connection failed", e);
    return false;
  }
}

// In-memory fallback data
export const memory = {
  centres: [
    { name: "Vijayawada Blood Centre", address: "Gandhi Nagar, Vijayawada", city: "Vijayawada", phone: "+91 98765 43210", latitude: 16.5062, longitude: 80.6480, approved: true },
    { name: "Guntur Medical Centre", address: "Main Road, Guntur", city: "Guntur", phone: "+91 91234 56789", latitude: 16.2833, longitude: 80.4467, approved: true },
    { name: "Vijayawada Red Cross", address: "Krishna Nagar, Vijayawada", city: "Vijayawada", phone: "+91 99887 77665", latitude: 16.5200, longitude: 80.6300, approved: false },
    { name: "Guntur Apollo Blood Bank", address: "Hospital Lane, Guntur", city: "Guntur", phone: "+91 98765 12345", latitude: 16.2900, longitude: 80.4500, approved: true },
    { name: "Vijayawada Lifeline Centre", address: "Bandar Road, Vijayawada", city: "Vijayawada", phone: "+91 91234 98765", latitude: 16.5150, longitude: 80.6200, approved: false },
  ],
  donors: [
    { name: "Rahul Verma", city: "Vijayawada", bloodGroup: "A+", lastDonationDate: new Date().toISOString(), email: "rahul@example.com", address: "Gandhi Nagar, Vijayawada", latitude: 16.5062, longitude: 80.6480, phone: "+91 90000 00001", approved: true },
    { name: "Priya Sharma", city: "Guntur", bloodGroup: "O-", lastDonationDate: new Date(Date.now()-86400000*40).toISOString(), email: "priya@example.com", address: "Main Road, Guntur", latitude: 16.2833, longitude: 80.4467, phone: "+91 90000 00002", approved: true },
    { name: "Amit Singh", city: "Vijayawada", bloodGroup: "B+", lastDonationDate: new Date(Date.now()-86400000*70).toISOString(), email: "amit@example.com", address: "Krishna Nagar, Vijayawada", latitude: 16.5200, longitude: 80.6300, phone: "+91 90000 00003", approved: false },
    { name: "Sita Rao", city: "Guntur", bloodGroup: "A+", lastDonationDate: new Date().toISOString(), email: "sita@example.com", address: "Hospital Lane, Guntur", latitude: 16.2900, longitude: 80.4500, phone: "+91 90000 00004", approved: true },
    { name: "Arjun Kumar", city: "Vijayawada", bloodGroup: "A+", lastDonationDate: new Date().toISOString(), email: "arjun@example.com", address: "Bandar Road, Vijayawada", latitude: 16.5150, longitude: 80.6200, phone: "+91 90000 00005", approved: false },
    { name: "Kavya Singh", city: "Guntur", bloodGroup: "B-", lastDonationDate: new Date(Date.now()-86400000*30).toISOString(), email: "kavya.singh@example.com", address: "Business District, Guntur", latitude: 16.2800, longitude: 80.4600, phone: "+91 90000 00006", approved: true },
    { name: "Deepak Nair", city: "Vijayawada", bloodGroup: "AB+", lastDonationDate: new Date(Date.now()-86400000*60).toISOString(), email: "deepak.nair@example.com", address: "Naidu Hospital, Vijayawada", latitude: 16.5100, longitude: 80.6400, phone: "+91 90000 00007", approved: false },
  ],
  stocks: [
    { group: "A+", units: 62 },
    { group: "A-", units: 18 },
    { group: "B+", units: 45 },
    { group: "B-", units: 26 },
    { group: "AB+", units: 12 },
    { group: "AB-", units: 8 },
    { group: "O+", units: 95 },
    { group: "O-", units: 14 },
  ] as { group: BloodGroup; units: number }[],
  camps: [
    { name: "Vijayawada Community Drive", date: new Date(Date.now()+86400000*7).toISOString(), address: "Gandhi Nagar, Vijayawada", latitude: 16.5062, longitude: 80.6480, approved: true },
    { name: "Guntur Health Camp 2025", date: new Date(Date.now()+86400000*14).toISOString(), address: "Municipal Park, Guntur", latitude: 16.2833, longitude: 80.4467, approved: false },
    { name: "Vijayawada Marathon Blood Drive", date: new Date(Date.now()+86400000*21).toISOString(), address: "Prakasam Barrage, Vijayawada", latitude: 16.5200, longitude: 80.6300, approved: true },
    { name: "Guntur Corporate Donation Drive", date: new Date(Date.now()+86400000*10).toISOString(), address: "Business District, Guntur", latitude: 16.2900, longitude: 80.4500, approved: false },
    { name: "Vijayawada College Blood Camp", date: new Date(Date.now()+86400000*5).toISOString(), address: "Naidu Hospital Campus, Vijayawada", latitude: 16.5100, longitude: 80.6400, approved: true },
  ],
  volunteers: [
    { name: "Rajesh Kumar", email: "rajesh.kumar@example.com", phone: "+91 90123 45678", city: "Vijayawada", interests: "Blood Donation, Community Service" },
    { name: "Priya Desai", email: "priya.desai@example.com", phone: "+91 91234 56789", city: "Guntur", interests: "Healthcare, Volunteering" },
    { name: "Arjun Patel", email: "arjun.patel@example.com", phone: "+91 92345 67890", city: "Vijayawada", interests: "Emergency Response, Fundraising" },
    { name: "Sneha Gupta", email: "sneha.gupta@example.com", phone: "+91 93456 78901", city: "Guntur", interests: "Event Management, Blood Donation" },
    { name: "Vikram Singh", email: "vikram.singh@example.com", phone: "+91 94567 89012", city: "Vijayawada", interests: "Community Outreach, Training" },
  ] as { name: string; email?: string; phone?: string; city?: string; interests?: string }[],
  admins: [
    { name: 'Admin User', email: 'admin@hospital.com', password: 'adminpass', role: 'admin', hospitalId: null },
    { name: 'Nenavath Sai Amrutha', email: 'nenavathsaiamrutha@gmail.com', password: 'Amrutha@05', role: 'admin', hospitalId: null }
  ] as any[],
};

export const THRESHOLD = Number(process.env.STOCK_THRESHOLD || 20);

export const AUTH_SECRET = process.env.ADMIN_AUTH_SECRET || 'dev_secret_change_me';

export async function seedIfEmpty() {
  const ok = await connectMongo();
  if (!ok) return;
  const centreCount = await models.Centre.countDocuments();
  if (centreCount === 0) {
    await models.Centre.insertMany(memory.centres);
  }
  const donorCount = await models.Donor.countDocuments();
  if (donorCount === 0) {
    await models.Donor.insertMany(memory.donors);
  }
  const stockCount = await models.Stock.countDocuments();
  if (stockCount === 0) {
    await models.Stock.insertMany(memory.stocks);
  }
  const campCount = await models.Camp.countDocuments();
  if (campCount === 0) {
    await models.Camp.insertMany(memory.camps);
  }
}
