import { RequestHandler } from "express";
import { BLOOD_GROUPS, THRESHOLD, connectMongo, memory, models } from "../db";
import { sendEmail } from "../mail";
import { sendSMS } from "../sms";

export const getStocks: RequestHandler = async (_req, res) => {
  const ok = await connectMongo();
  if (ok) {
    const items = await models.Stock.find({}, { _id: 0, group: 1, units: 1 }).lean();
    res.json(items);
  } else {
    res.json(memory.stocks);
  }
};

export const getCentres: RequestHandler = async (_req, res) => {
  const ok = await connectMongo();
  if (ok) {
    const items = await models.Centre.find({}).lean();
    res.json(items);
  } else {
    res.json(memory.centres);
  }
};

export const getDonors: RequestHandler = async (_req, res) => {
  const ok = await connectMongo();
  if (ok) {
    const items = await models.Donor.find({}, { name: 1, city: 1, bloodGroup: 1, lastDonationDate: 1 }).lean();
    res.json(items);
  } else {
    // Memory fallback should only expose non-sensitive fields (same projection as DB)
    const items = (memory.donors || []).map((d: any) => ({ name: d.name, city: d.city, bloodGroup: d.bloodGroup, lastDonationDate: d.lastDonationDate }));
    res.json(items);
  }
};

export const getCamps: RequestHandler = async (_req, res) => {
  const ok = await connectMongo();
  if (ok) {
    const items = await models.Camp.find({}, { name: 1, date: 1, address: 1, latitude: 1, longitude: 1 }).lean();
    res.json(items);
  } else {
    res.json(memory.camps);
  }
};

export const postVolunteer: RequestHandler = async (req, res) => {
  const { name, email, phone, city, interests } = req.body || {};
  if (!name) return res.status(400).json({ error: "name is required" });

  const ok = await connectMongo();
  if (ok) {
    const v = await models.Volunteer.create({ name, email, phone, city, interests });
    res.status(201).json(v.toObject());
  } else {
    const v = { name, email, phone, city, interests };
    memory.volunteers.push(v);
    res.status(201).json(v);
  }
};

export const postDonor: RequestHandler = async (req, res) => {
  const { name, age, gender, bloodGroup, lastDonationDate, phone, city, email, dob, hemoglobin, diseases, address } = req.body || {};
  if (!name || !bloodGroup) return res.status(400).json({ error: "name and bloodGroup are required" });

  const ok = await connectMongo();
  if (ok) {
    const d = await models.Donor.create({
      name,
      age,
      gender,
      bloodGroup,
      lastDonationDate: lastDonationDate ? new Date(lastDonationDate) : undefined,
      phone,
      city,
      email,
      dob: dob ? new Date(dob) : undefined,
      hemoglobin,
      diseases,
      address,
    });
    res.status(201).json(d.toObject());
  } else {
    const d = { name, age, gender, bloodGroup, lastDonationDate, phone, city, email, dob, hemoglobin, diseases, address };
    memory.donors.push(d as any);
    res.status(201).json(d);
  }
};

export const getAlerts: RequestHandler = async (_req, res) => {
  let stocks;
  const ok = await connectMongo();
  if (ok) {
    stocks = await models.Stock.find({}, { group: 1, units: 1 }).lean();
  } else {
    stocks = memory.stocks;
  }
  const lowStock = stocks.filter((s: any) => s.units < THRESHOLD).sort((a: any, b: any) => a.units - b.units);
  res.json({ lowStock, threshold: THRESHOLD });
};

export const getStats: RequestHandler = async (_req, res) => {
  let donors = 0, centres = 0, camps = 0, stocks: any[] = [];
  const ok = await connectMongo();
  if (ok) {
    donors = await models.Donor.countDocuments();
    centres = await models.Centre.countDocuments();
    camps = await models.Camp.countDocuments({ date: { $gte: new Date() } });
    stocks = await models.Stock.find({}, { group: 1, units: 1 }).lean();
  } else {
    donors = memory.donors.length;
    centres = memory.centres.length;
    camps = memory.camps.filter((c) => new Date(c.date) >= new Date()).length;
    stocks = memory.stocks;
  }
  const totalUnits = stocks.reduce((sum, s) => sum + (s.units || 0), 0);
  const lowStock = stocks.filter((s: any) => s.units < THRESHOLD).sort((a: any, b: any) => a.units - b.units);
  res.json({ totalUnits, totalDonors: donors, totalCentres: centres, upcomingCamps: camps, lowStock });
};

// Search centres by blood group near a lat/lng (meters)
export const searchByGroup: RequestHandler = async (req, res) => {
  const lat = parseFloat((req.query.lat as string) || "");
  const lng = parseFloat((req.query.lng as string) || "");
  const group = (req.query.group as string) || "";
  const radiusMeters = Number(req.query.radiusMeters || 5000);

  if (Number.isNaN(lat) || Number.isNaN(lng)) return res.status(400).json({ error: "lat and lng required" });
  if (!group) return res.status(400).json({ error: "group required" });

  // haversine
  function haversine(a: { lat: number; lng: number }, b: { lat: number; lng: number }) {
    const R = 6371e3; // m
    const toRad = (v: number) => (v * Math.PI) / 180;
    const φ1 = toRad(a.lat);
    const φ2 = toRad(b.lat);
    const Δφ = toRad(b.lat - a.lat);
    const Δλ = toRad(b.lng - a.lng);
    const sa = Math.sin(Δφ / 2) * Math.sin(Δφ / 2) + Math.cos(φ1) * Math.cos(φ2) * Math.sin(Δλ / 2) * Math.sin(Δλ / 2);
    const c = 2 * Math.atan2(Math.sqrt(sa), Math.sqrt(1 - sa));
    return R * c;
  }

  const ok = await connectMongo();
  if (ok) {
    // find centres and their stock for group
    const centres = await models.Centre.find({}).lean();
    const stocks = await models.Stock.find({ group }).lean();
    // map centreId to units
    const map = new Map<string, number>();
    stocks.forEach((s: any) => {
      if (s.centreId) map.set(String(s.centreId), s.units || 0);
    });

    // If no per-centre stock mapping exists, fall back to any group-level stock entries
    if (map.size === 0) {
      const groupStock = stocks.find((s: any) => (s.units || 0) > 0);
      if (groupStock) {
        const unitsAvailable = groupStock.units || 0;
        const results = centres
          .map((c: any) => {
            const distance = haversine({ lat, lng }, { lat: c.latitude || 0, lng: c.longitude || 0 });
            return { name: c.name, phone: c.phone, address: c.address, latitude: c.latitude, longitude: c.longitude, units: unitsAvailable, distance };
          })
          .filter((r) => r.distance <= radiusMeters)
          .sort((a, b) => a.distance - b.distance);
        return res.json(results);
      }
    }

    let results = centres
      .map((c: any) => {
        const units = map.get(String(c._id)) ?? 0;
        const distance = haversine({ lat, lng }, { lat: c.latitude || 0, lng: c.longitude || 0 });
        return { id: c._id, type: 'centre', name: c.name, phone: c.phone, address: c.address, latitude: c.latitude, longitude: c.longitude, units, distance };
      })
      .filter((r) => r.distance <= radiusMeters)
      .sort((a, b) => a.distance - b.distance);

    // Include donors who match the group and have coordinates
    const donorDocs = await models.Donor.find({ bloodGroup: group, latitude: { $exists: true }, longitude: { $exists: true } }).lean();
    // Do not expose donor contact details in public search results — only include minimal info
    const donorResults = donorDocs
      .map((d: any) => {
        const distance = haversine({ lat, lng }, { lat: d.latitude || 0, lng: d.longitude || 0 });
        return { id: d._id, type: 'donor', name: d.name, latitude: d.latitude, longitude: d.longitude, units: 0, distance };
      })
      .filter((r) => r.distance <= radiusMeters)
      .sort((a, b) => a.distance - b.distance);

    // Combine centre and donor results, sort by distance
    results = [...results, ...donorResults].sort((a, b) => a.distance - b.distance);

    // Prefer centres with units > 0, but if none exist, still return nearby centres/donors
    const withStock = results.filter((r) => r.units > 0);
    if (withStock.length > 0) {
      results = withStock;
    }

    res.json(results);
  } else {
    // memory fallback: use memory.centres and memory.stocks global (global stock not per centre)
    const global = memory.stocks.find((s: any) => s.group === group);
    const unitsAvailable = global ? global.units : 0;
    // If no global units, still return nearby centres with units set to 0 so the map shows locations
    const centreResults = memory.centres
      .map((c: any) => {
        const distance = haversine({ lat, lng }, { lat: c.latitude || 0, lng: c.longitude || 0 });
        return { id: c.name, type: 'centre', name: c.name, phone: c.phone, address: c.address, latitude: c.latitude, longitude: c.longitude, units: unitsAvailable || 0, distance };
      })
      .filter((r) => r.distance <= radiusMeters)
      .sort((a, b) => a.distance - b.distance);

    const donorResults = (memory.donors || [])
      .filter((d: any) => d.bloodGroup === group && d.latitude && d.longitude)
      .map((d: any) => {
        const distance = haversine({ lat, lng }, { lat: d.latitude || 0, lng: d.longitude || 0 });
        // Only expose minimal donor info in the public fallback
        return { id: d.email || d.name, type: 'donor', name: d.name, latitude: d.latitude, longitude: d.longitude, units: 0, distance };
      })
      .filter((r: any) => r.distance <= radiusMeters)
      .sort((a: any, b: any) => a.distance - b.distance);

    const results = [...centreResults, ...donorResults].sort((a: any, b: any) => a.distance - b.distance);
    res.json(results);
  }
};

// --- Auth utilities: PBKDF2 password hashing and HMAC-signed tokens (JWT-like) ---
import crypto from 'crypto';
import { AUTH_SECRET } from '../db';

function base64url(input: string) {
  return Buffer.from(input).toString('base64').replace(/=/g, '').replace(/\+/g, '-').replace(/\//g, '_');
}
function base64urlDecode(input: string) {
  const b = input.replace(/-/g, '+').replace(/_/g, '/');
  // Add padding if needed
  const padding = (4 - (b.length % 4)) % 4;
  const padded = b + '='.repeat(padding);
  return Buffer.from(padded, 'base64').toString('utf8');
}

function signPayload(payload: object, expiresInSeconds = 60 * 60 * 12) {
  const exp = Math.floor(Date.now() / 1000) + expiresInSeconds;
  const obj = { ...payload, exp };
  const str = JSON.stringify(obj);
  const b64 = base64url(str);
  const sig = crypto.createHmac('sha256', AUTH_SECRET).update(b64).digest('hex');
  return `${b64}.${sig}`;
}
function verifyToken(token: string) {
  try {
    const parts = token.split('.');
    if (parts.length !== 2) {
      console.log('[VERIFY] Token does not have 2 parts:', parts.length);
      return null;
    }
    const [b64, sig] = parts;
    const expected = crypto.createHmac('sha256', AUTH_SECRET).update(b64).digest('hex');
    if (!crypto.timingSafeEqual(Buffer.from(expected, 'hex'), Buffer.from(sig, 'hex'))) {
      console.log('[VERIFY] Signature mismatch. Expected:', expected.substring(0, 20), 'Got:', sig.substring(0, 20));
      return null;
    }
    const payload = JSON.parse(base64urlDecode(b64));
    if (payload.exp && Math.floor(Date.now() / 1000) > payload.exp) {
      console.log('[VERIFY] Token expired');
      return null;
    }
    return payload;
  } catch (e) {
    console.log('[VERIFY] Token verification error:', (e as any)?.message);
    return null;
  }
}
function getAdminFromReq(req: any) {
  const h = req.headers?.authorization || req.headers?.Authorization;
  if (!h) {
    console.log('[AUTH] No authorization header found');
    return null;
  }
  const m = String(h).match(/^Bearer\s+(.*)$/i);
  if (!m) {
    console.log('[AUTH] Authorization header does not match Bearer format:', h);
    return null;
  }
  const token = m[1];
  const result = verifyToken(token);
  if (!result) {
    console.log('[AUTH] Token verification failed for token:', token.substring(0, 20) + '...');
  } else {
    console.log('[AUTH] Token verified successfully for:', result.email);
  }
  return result;
}

// Password hashing using PBKDF2 (sync for simplicity)
function hashPassword(password: string) {
  const salt = crypto.randomBytes(16).toString('hex');
  const iterations = 150000;
  const dk = crypto.pbkdf2Sync(password, salt, iterations, 32, 'sha256').toString('hex');
  return `pbkdf2$${iterations}$${salt}$${dk}`;
}
function verifyPassword(password: string, stored: string) {
  if (!stored || !stored.startsWith('pbkdf2$')) {
    // legacy plain-text fallback
    return password === stored;
  }
  const parts = stored.split('$');
  if (parts.length !== 4) return false;
  const iterations = Number(parts[1]);
  const salt = parts[2];
  const dk = parts[3];
  const computed = crypto.pbkdf2Sync(password, salt, iterations, 32, 'sha256').toString('hex');
  try {
    return crypto.timingSafeEqual(Buffer.from(computed, 'hex'), Buffer.from(dk, 'hex'));
  } catch (e) {
    return false;
  }
}

export const adminLogin: RequestHandler = async (req, res) => {
  const { email, password } = req.body || {};
  if (!email || !password) return res.status(400).json({ error: 'email and password required' });

  const ok = await connectMongo();
  if (ok) {
    const admin = await models.Admin.findOne({ email }).lean();
    if (!admin || !verifyPassword(password, admin.password)) return res.status(401).json({ error: 'invalid credentials' });
    if (admin.role !== 'admin') return res.status(403).json({ error: 'not authorized' });
    const payload = { email: admin.email, role: admin.role, hospitalId: admin.hospitalId, name: admin.name };
    const token = signPayload(payload);
    return res.json({ token, admin: payload });
  } else {
    // memory fallback: support hashed passwords; if legacy plain text exists, accept and upgrade
    const idx = memory.admins.findIndex((a: any) => a.email === email);
    if (idx === -1) return res.status(401).json({ error: 'invalid credentials' });
    const admin = memory.admins[idx];
    if (!verifyPassword(password, admin.password)) return res.status(401).json({ error: 'invalid credentials' });
    // upgrade plain to hashed if needed
    if (!admin.password.startsWith('pbkdf2$')) {
      memory.admins[idx].password = hashPassword(admin.password);
    }
    if (admin.role !== 'admin') return res.status(403).json({ error: 'not authorized' });
    const payload = { email: admin.email, role: admin.role, hospitalId: admin.hospitalId, name: admin.name };
    const token = signPayload(payload);
    return res.json({ token, admin: payload });
  }
};

// Admin signup (create new admin). If admins exist, require an existing admin token; otherwise allow initial signup.
export const adminSignup: RequestHandler = async (req, res) => {
  const { name, email, password, role = 'admin', hospitalId } = req.body || {};
  if (!name || !email || !password) return res.status(400).json({ error: 'name, email and password required' });

  const ok = await connectMongo();
  if (ok) {
    const existing = await models.Admin.findOne({}).lean();
    if (existing) {
      // require admin token
      const adminPayload = getAdminFromReq(req);
      if (!adminPayload) return res.status(401).json({ error: 'unauthenticated' });
      if (adminPayload.role !== 'admin') return res.status(403).json({ error: 'forbidden' });
    }
    const hashed = hashPassword(password);
    const a = await models.Admin.create({ name, email, password: hashed, role, hospitalId });
    return res.status(201).json({ email: a.email, name: a.name, role: a.role, hospitalId: a.hospitalId });
  } else {
    // memory mode: if any admins exist, require token
    if (memory.admins && memory.admins.length > 0) {
      const adminPayload = getAdminFromReq(req);
      if (!adminPayload) return res.status(401).json({ error: 'unauthenticated' });
      if (adminPayload.role !== 'admin') return res.status(403).json({ error: 'forbidden' });
    }
    const hashed = hashPassword(password);
    const a = { name, email, password: hashed, role, hospitalId };
    memory.admins.push(a);
    return res.status(201).json({ email: a.email, name: a.name, role: a.role, hospitalId: a.hospitalId });
  }
};

// Admin list and management endpoints (protected)
export const adminList: RequestHandler = async (req, res) => {
  const adminPayload = getAdminFromReq(req);
  if (!adminPayload) return res.status(401).json({ error: 'unauthenticated' });
  if (adminPayload.role !== 'admin') return res.status(403).json({ error: 'forbidden' });
  const ok = await connectMongo();
  if (ok) {
    const items = await models.Admin.find({}, { password: 0 }).lean();
    return res.json(items);
  } else {
    const items = (memory.admins || []).map((a: any) => ({ name: a.name, email: a.email, role: a.role, hospitalId: a.hospitalId }));
    return res.json(items);
  }
};

export const adminDelete: RequestHandler = async (req, res) => {
  const adminPayload = getAdminFromReq(req);
  if (!adminPayload) return res.status(401).json({ error: 'unauthenticated' });
  if (adminPayload.role !== 'admin') return res.status(403).json({ error: 'forbidden' });
  const id = req.params.id;
  const ok = await connectMongo();
  if (ok) {
    try {
      await models.Admin.findByIdAndDelete(id);
      return res.json({ ok: true });
    } catch (e) {
      return res.status(400).json({ error: 'invalid id' });
    }
  } else {
    const idx = memory.admins.findIndex((a: any) => a.email === id || a.email === id);
    if (idx === -1) return res.status(404).json({ error: 'not found' });
    memory.admins.splice(idx, 1);
    return res.json({ ok: true });
  }
};

// Admin endpoints (now require authorization header)

export const adminGetDonors: RequestHandler = async (req, res) => {
  const admin = getAdminFromReq(req);
  if (!admin) return res.status(401).json({ error: 'unauthenticated' });
  if (admin.role !== 'admin') return res.status(403).json({ error: 'forbidden' });

  const ok = await connectMongo();
  if (ok) {
    const filter: any = {};
    if (admin.hospitalId) filter.hospitalId = admin.hospitalId;
    const items = await models.Donor.find(filter).lean();
    res.json(items);
  } else {
    // ensure approved flag exists and filter by hospitalId when present
    const items = memory.donors
      .map((d: any) => ({ ...d, approved: d.approved ?? false }))
      .filter((d: any) => (admin.hospitalId ? d.hospitalId === admin.hospitalId : true));
    res.json(items);
  }
};

export const adminApproveDonor: RequestHandler = async (req, res) => {
  const id = req.params.id;
  const admin = getAdminFromReq(req);
  if (!admin) return res.status(401).json({ error: 'unauthenticated' });
  if (admin.role !== 'admin') return res.status(403).json({ error: 'forbidden' });

  const ok = await connectMongo();
  if (ok) {
    try {
      const donor = await models.Donor.findById(id).lean();
      if (!donor) return res.status(404).json({ error: 'Donor not found' });
      // enforce hospital scoping
      if (admin.hospitalId && String(donor.hospitalId) !== String(admin.hospitalId)) return res.status(403).json({ error: 'not allowed' });
      const updated = await models.Donor.findByIdAndUpdate(id, { $set: { approved: true } }, { new: true }).lean();
      return res.json(updated);
    } catch (e) {
      return res.status(400).json({ error: 'Invalid id' });
    }
  } else {
    // find by email or name
    const idx = memory.donors.findIndex((d: any) => d.email === id || d.name === id);
    if (idx === -1) return res.status(404).json({ error: 'Donor not found' });
    (memory.donors[idx] as any).approved = true;
    return res.json(memory.donors[idx]);
  }
};

export const adminRejectDonor: RequestHandler = async (req, res) => {
  const id = req.params.id;
  const admin = getAdminFromReq(req);
  if (!admin) return res.status(401).json({ error: 'unauthenticated' });
  if (admin.role !== 'admin') return res.status(403).json({ error: 'forbidden' });

  const ok = await connectMongo();
  if (ok) {
    try {
      const donor = await models.Donor.findById(id).lean();
      if (!donor) return res.status(404).json({ error: 'Donor not found' });
      if (admin.hospitalId && String(donor.hospitalId) !== String(admin.hospitalId)) return res.status(403).json({ error: 'not allowed' });
      const updated = await models.Donor.findByIdAndUpdate(id, { $set: { approved: false } }, { new: true }).lean();
      return res.json(updated);
    } catch (e) {
      return res.status(400).json({ error: 'Invalid id' });
    }
  } else {
    const idx = memory.donors.findIndex((d: any) => d.email === id || d.name === id);
    if (idx === -1) return res.status(404).json({ error: 'Donor not found' });
    (memory.donors[idx] as any).approved = false;
    return res.json(memory.donors[idx]);
  }
};

// Admin: broadcast emergency alert to matching donors.
export const adminSendEmergencyAlert: RequestHandler = async (req, res) => {
  const { bloodGroup, city, contactNumber, customMessage, method } = req.body || {};
  const admin = getAdminFromReq(req);
  if (!admin) return res.status(401).json({ error: 'unauthenticated' });
  if (admin.role !== 'admin') return res.status(403).json({ error: 'forbidden' });

  if (!bloodGroup || !contactNumber) return res.status(400).json({ error: 'bloodGroup and contactNumber required' });
  if (!['sms', 'email'].includes(method)) return res.status(400).json({ error: 'invalid method' });

  const ok = await connectMongo();
  let donors: any[] = [];

  if (ok) {
    const filter: any = { bloodGroup };
    if (city) filter.city = { $regex: city, $options: 'i' };
    donors = await models.Donor.find(filter).lean();
  } else {
    donors = (memory.donors || []).filter((d: any) => {
      if (d.bloodGroup !== bloodGroup) return false;
      if (city && (!d.city || !d.city.toLowerCase().includes(city.toLowerCase()))) return false;
      return true;
    });
  }

  // Dynamic import of mail utility
  let sendBulkEmails: any = null;
  try {
    const mailModule = await import('../mail');
    sendBulkEmails = mailModule.sendBulkEmails;
  } catch (e) {
    // Mail module not available, will use simulated delivery
    // eslint-disable-next-line no-console
    console.warn('Mail module not available, using simulated delivery', e);
  }

  memory.notifications = memory.notifications || [];
  let sentCount = 0;
  let emailsSent = 0;
  let emailsFailed = 0;

  if (method === 'email' && sendBulkEmails) {
    // Collect email recipients
    const emailRecipients = donors
      .filter((d: any) => d.email)
      .map((d: any) => d.email);

    if (emailRecipients.length > 0) {
      let subject = `Urgent Requirement – ${bloodGroup} Blood Needed`;
      let htmlBody = customMessage || `<p>Hello Donor,</p>
<p>We have an emergency case that requires <strong>${bloodGroup}</strong> blood immediately.</p>
<p>If you are available to donate, please reply to this message or contact us at: <strong>${contactNumber}</strong></p>
<p>Your help can save a life. Thank you.</p>`;

      const result = await sendBulkEmails(emailRecipients, subject, htmlBody);
      emailsSent = result.sent;
      emailsFailed = result.failed;
      sentCount = emailsSent;
    }
  } else if (method === 'sms') {
    // SMS delivery (simulated, logs to console)
    donors.forEach((donor: any) => {
      const to = donor.phone;
      if (!to) return;

      let message = customMessage;
      if (!message) {
        message = `Hello, this is an urgent request from our Blood Bank. We need ${bloodGroup} blood immediately for an emergency case. If you are available to donate, please contact: ${contactNumber}. Thank you.`;
      }

      const record = {
        donorId: donor._id ?? donor.email ?? donor.name,
        method: 'sms',
        message,
        to,
        sentAt: new Date().toISOString(),
        admin: admin.email || admin.name,
        type: 'emergency',
        simulated: true,
      };
      memory.notifications.push(record);
      sentCount++;

      // eslint-disable-next-line no-console
      console.info('SMS alert queued (simulated):', record);
    });
  }

  // Record email notifications in memory for audit trail
  if (method === 'email') {
    donors
      .filter((d: any) => d.email)
      .forEach((donor: any) => {
        const record = {
          donorId: donor._id ?? donor.email ?? donor.name,
          method: 'email',
          message: customMessage || `Emergency request for ${bloodGroup} blood. Contact: ${contactNumber}`,
          to: donor.email,
          sentAt: new Date().toISOString(),
          admin: admin.email || admin.name,
          type: 'emergency',
          delivered: emailsSent > 0,
        };
        memory.notifications.push(record);
      });
  }

  res.json({ ok: true, sentCount, emailsSent, emailsFailed, method, simulated: method === 'sms' });
};

// Admin: notify a donor (simulated delivery).
export const adminNotifyDonor: RequestHandler = async (req, res) => {
  const id = req.params.id;
  const { method, message } = req.body || {};
  const admin = getAdminFromReq(req);
  if (!admin) return res.status(401).json({ error: 'unauthenticated' });
  if (admin.role !== 'admin') return res.status(403).json({ error: 'forbidden' });

  if (!method || !message) return res.status(400).json({ error: 'method and message required' });

  const ok = await connectMongo();
  let donor: any = null;
  if (ok) {
    try {
      donor = await models.Donor.findById(id).lean();
      if (!donor) {
        // try fallback by email or name
        donor = await models.Donor.findOne({ $or: [{ email: id }, { name: id }] }).lean();
      }
    } catch (e) {
      // ignore
    }
  } else {
    donor = (memory.donors || []).find((d: any) => d._id === id || d.email === id || d.name === id);
  }

  if (!donor) return res.status(404).json({ error: 'Donor not found' });

  // Get contact information
  const emailAddress = donor.email;
  const phoneNumber = donor.phone;

  // Validate contact method
  if (method === 'email' && !emailAddress) {
    return res.status(400).json({ error: 'Donor has no email contact' });
  }
  if (method === 'sms' && !phoneNumber) {
    return res.status(400).json({ error: 'Donor has no phone contact' });
  }

  // Send notification
  let success = false;
  let deliveryInfo = { method, to: '', status: 'pending' };

  try {
    if (method === 'email') {
      const htmlContent = `
        <h2>Urgent Blood Donation Request</h2>
        <p>Dear ${donor.name},</p>
        <p>${message}</p>
        <p>Blood Group Needed: ${donor.bloodGroup}</p>
        <p>Please contact the blood bank immediately if you can help.</p>
        <p>Thank you for saving lives!</p>
      `;
      success = await sendEmail(emailAddress, 'Urgent Blood Donation Request', htmlContent);
      deliveryInfo.to = emailAddress;
    } else if (method === 'sms') {
      success = await sendSMS(phoneNumber, `[Blood Bank] ${message}. Please contact immediately. Blood Group: ${donor.bloodGroup}`);
      deliveryInfo.to = phoneNumber;
    }

    deliveryInfo.status = success ? 'sent' : 'failed';
  } catch (error: any) {
    // eslint-disable-next-line no-console
    console.error('Notification delivery error:', error?.message);
    deliveryInfo.status = 'error';
  }

  // Record notification in memory for audit trail
  memory.notifications = memory.notifications || [];
  const record = {
    donorId: donor._id ?? donor.email ?? donor.name,
    method,
    message,
    to: deliveryInfo.to,
    status: deliveryInfo.status,
    sentAt: new Date().toISOString(),
    admin: admin.email || admin.name
  };
  memory.notifications.push(record);

  // eslint-disable-next-line no-console
  console.info('Notification sent:', record);

  return res.json({
    ok: success,
    method,
    to: deliveryInfo.to,
    status: deliveryInfo.status,
    message: success ? `Notification sent via ${method}` : `Failed to send notification via ${method}`
  });
};

export const adminGetCentres: RequestHandler = async (req, res) => {
  const admin = getAdminFromReq(req);
  if (!admin) return res.status(401).json({ error: 'unauthenticated' });
  if (admin.role !== 'admin') return res.status(403).json({ error: 'forbidden' });

  const ok = await connectMongo();
  if (ok) {
    const items = await models.Centre.find({}).lean();
    res.json(items);
  } else {
    const items = memory.centres.map((c: any) => ({ ...c, approved: c.approved ?? false }));
    res.json(items);
  }
};

export const adminApproveCentre: RequestHandler = async (req, res) => {
  const admin = getAdminFromReq(req);
  if (!admin) return res.status(401).json({ error: 'unauthenticated' });
  if (admin.role !== 'admin') return res.status(403).json({ error: 'forbidden' });
  const id = req.params.id;
  const ok = await connectMongo();
  if (ok) {
    try {
      const updated = await models.Centre.findByIdAndUpdate(id, { $set: { approved: true } }, { new: true }).lean();
      return res.json(updated);
    } catch (e) {
      return res.status(400).json({ error: 'Invalid id' });
    }
  } else {
    const idx = memory.centres.findIndex((c: any) => c.name === id);
    if (idx === -1) return res.status(404).json({ error: 'Centre not found' });
    (memory.centres[idx] as any).approved = true;
    return res.json(memory.centres[idx]);
  }
};

export const adminRejectCentre: RequestHandler = async (req, res) => {
  const admin = getAdminFromReq(req);
  if (!admin) return res.status(401).json({ error: 'unauthenticated' });
  if (admin.role !== 'admin') return res.status(403).json({ error: 'forbidden' });
  const id = req.params.id;
  const ok = await connectMongo();
  if (ok) {
    try {
      const updated = await models.Centre.findByIdAndUpdate(id, { $set: { approved: false } }, { new: true }).lean();
      return res.json(updated);
    } catch (e) {
      return res.status(400).json({ error: 'Invalid id' });
    }
  } else {
    const idx = memory.centres.findIndex((c: any) => c.name === id);
    if (idx === -1) return res.status(404).json({ error: 'Centre not found' });
    (memory.centres[idx] as any).approved = false;
    return res.json(memory.centres[idx]);
  }
};

export const adminGetCamps: RequestHandler = async (req, res) => {
  const admin = getAdminFromReq(req);
  if (!admin) return res.status(401).json({ error: 'unauthenticated' });
  if (admin.role !== 'admin') return res.status(403).json({ error: 'forbidden' });

  const ok = await connectMongo();
  if (ok) {
    const items = await models.Camp.find({}).lean();
    res.json(items);
  } else {
    const items = memory.camps.map((c: any) => ({ ...c, approved: c.approved ?? false }));
    res.json(items);
  }
};

// Admin: list volunteers
export const adminGetVolunteers: RequestHandler = async (req, res) => {
  const admin = getAdminFromReq(req);
  if (!admin) return res.status(401).json({ error: 'unauthenticated' });
  if (admin.role !== 'admin') return res.status(403).json({ error: 'forbidden' });

  const ok = await connectMongo();
  if (ok) {
    const filter: any = {};
    if (admin.hospitalId) filter.hospitalId = admin.hospitalId;
    const items = await models.Volunteer.find(filter).lean();

    // If DB is connected but empty, merge in-memory volunteers (useful for dev mode where some posts went to memory)
    if ((!items || items.length === 0) && (memory.volunteers || []).length > 0) {
      const fallback = (memory.volunteers || []).map((v: any) => ({ ...v }));
      const filtered = admin.hospitalId ? fallback.filter((v: any) => v.hospitalId === admin.hospitalId) : fallback;
      return res.json(filtered);
    }

    return res.json(items);
  } else {
    const items = (memory.volunteers || []).map((v: any) => ({ ...v }));
    const filtered = admin.hospitalId ? items.filter((v: any) => v.hospitalId === admin.hospitalId) : items;
    res.json(filtered);
  }
};

// Admin debug: volunteers status (counts and samples)
export const adminDebugVolunteers: RequestHandler = async (req, res) => {
  const admin = getAdminFromReq(req);
  if (!admin) return res.status(401).json({ error: 'unauthenticated' });
  if (admin.role !== 'admin') return res.status(403).json({ error: 'forbidden' });

  const ok = await connectMongo();
  const memoryCount = (memory.volunteers || []).length;
  let dbCount = 0;
  let dbItems: any[] = [];
  if (ok) {
    dbCount = await models.Volunteer.countDocuments();
    dbItems = await models.Volunteer.find({}, { name: 1, email: 1, phone: 1, city: 1 }).limit(20).lean();
  }

  return res.json({ dbConnected: ok, dbCount, memoryCount, memoryPreview: (memory.volunteers || []).slice(0, 20), dbPreview: dbItems });
};

// Admin: delete volunteer
export const adminDeleteVolunteer: RequestHandler = async (req, res) => {
  const admin = getAdminFromReq(req);
  if (!admin) return res.status(401).json({ error: 'unauthenticated' });
  if (admin.role !== 'admin') return res.status(403).json({ error: 'forbidden' });

  const id = req.params.id;
  const ok = await connectMongo();
  if (ok) {
    try {
      await models.Volunteer.findByIdAndDelete(id);
      return res.json({ ok: true });
    } catch (e) {
      return res.status(400).json({ error: 'Invalid id' });
    }
  } else {
    const idx = (memory.volunteers || []).findIndex((v: any) => v.email === id || v.name === id);
    if (idx === -1) return res.status(404).json({ error: 'Volunteer not found' });
    memory.volunteers.splice(idx, 1);
    return res.json({ ok: true });
  }
};

export const adminApproveCamp: RequestHandler = async (req, res) => {
  const admin = getAdminFromReq(req);
  if (!admin) return res.status(401).json({ error: 'unauthenticated' });
  if (admin.role !== 'admin') return res.status(403).json({ error: 'forbidden' });
  const id = req.params.id;
  const ok = await connectMongo();
  if (ok) {
    try {
      const updated = await models.Camp.findByIdAndUpdate(id, { $set: { approved: true } }, { new: true }).lean();
      return res.json(updated);
    } catch (e) {
      return res.status(400).json({ error: 'Invalid id' });
    }
  } else {
    const idx = memory.camps.findIndex((c: any) => c.name === id);
    if (idx === -1) return res.status(404).json({ error: 'Camp not found' });
    (memory.camps[idx] as any).approved = true;
    return res.json(memory.camps[idx]);
  }
};

export const adminRejectCamp: RequestHandler = async (req, res) => {
  const admin = getAdminFromReq(req);
  if (!admin) return res.status(401).json({ error: 'unauthenticated' });
  if (admin.role !== 'admin') return res.status(403).json({ error: 'forbidden' });
  const id = req.params.id;
  const ok = await connectMongo();
  if (ok) {
    try {
      const updated = await models.Camp.findByIdAndUpdate(id, { $set: { approved: false } }, { new: true }).lean();
      return res.json(updated);
    } catch (e) {
      return res.status(400).json({ error: 'Invalid id' });
    }
  } else {
    const idx = memory.camps.findIndex((c: any) => c.name === id);
    if (idx === -1) return res.status(404).json({ error: 'Camp not found' });
    (memory.camps[idx] as any).approved = false;
    return res.json(memory.camps[idx]);
  }
};

// exported earlier: adminLogin is defined above in this file

// Debug (unauthenticated): return in-memory volunteers only (for quick verification in dev)
export const debugMemoryVolunteersPublic: RequestHandler = async (_req, res) => {
  const items = (memory.volunteers || []).map((v: any) => ({ name: v.name, email: v.email, phone: v.phone, city: v.city }));
  return res.json({ memoryCount: items.length, memoryPreview: items });
};
