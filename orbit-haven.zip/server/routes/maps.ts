import { RequestHandler } from "express";

export const getKey: RequestHandler = (_req, res) => {
  const key = process.env.GOOGLE_MAPS_API_KEY || null;
  res.json({ key });
};
