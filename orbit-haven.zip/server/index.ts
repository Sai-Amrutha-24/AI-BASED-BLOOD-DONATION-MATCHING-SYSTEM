import "dotenv/config";
import express from "express";
import cors from "cors";
import { handleDemo } from "./routes/demo";

export async function createServer() {
  const app = express();

  // Middleware
  app.use(cors());
  app.use(express.json());
  app.use(express.urlencoded({ extended: true }));

  // Enforce HTTPS for incoming requests when configured (production only)
  // Set ENFORCE_HTTPS=true to enable in production. Behind proxies (Vercel/Netlify/Fly) x-forwarded-proto is checked.
  if (process.env.ENFORCE_HTTPS === 'true' && process.env.NODE_ENV === 'production') {
    app.use((req, res, next) => {
      const proto = (req.headers['x-forwarded-proto'] || '') as string;
      if ((req as any).secure || proto.toLowerCase().includes('https')) {
        return next();
      }
      // Reject non-HTTPS requests for security-sensitive endpoints
      res.status(400).json({ error: 'HTTPS required' });
    });
  } else if (process.env.ENFORCE_HTTPS === 'true') {
    // In non-production (dev), we do not enforce HTTPS to allow local testing
    // eslint-disable-next-line no-console
    console.warn('ENFORCE_HTTPS is true but NODE_ENV != production — skipping HTTPS enforcement in development');
  }

  // Example API routes
  app.get("/api/ping", (_req, res) => {
    const ping = process.env.PING_MESSAGE ?? "ping";
    res.json({ message: ping });
  });

  app.get("/api/demo", handleDemo);

  // Blood bank API
  const b = await import("./routes/blood");
  app.get("/api/stocks", b.getStocks);
  app.get("/api/centres", b.getCentres);
  app.get("/api/donors", b.getDonors);
  app.post("/api/donors", b.postDonor);
  app.get("/api/camps", b.getCamps);
  app.post("/api/volunteers", b.postVolunteer);
  app.get("/api/alerts", b.getAlerts);
  app.get("/api/stats", b.getStats);
  app.get("/api/search-by-group", b.searchByGroup);

  // Admin endpoints
  app.post('/api/admin/login', b.adminLogin);
  app.post('/api/admin/signup', b.adminSignup);
  app.get('/api/admins', b.adminList);
  app.delete('/api/admins/:id', b.adminDelete);

  app.get('/api/admin/donors', b.adminGetDonors);
  app.patch('/api/admin/donors/:id/approve', b.adminApproveDonor);
  app.patch('/api/admin/donors/:id/reject', b.adminRejectDonor);
  app.post('/api/admin/donors/:id/notify', b.adminNotifyDonor);
  app.post('/api/admin/emergency-alert', b.adminSendEmergencyAlert);

  app.get('/api/admin/centres', b.adminGetCentres);
  app.patch('/api/admin/centres/:id/approve', b.adminApproveCentre);
  app.patch('/api/admin/centres/:id/reject', b.adminRejectCentre);

  app.get('/api/admin/camps', b.adminGetCamps);
  app.patch('/api/admin/camps/:id/approve', b.adminApproveCamp);
  app.patch('/api/admin/camps/:id/reject', b.adminRejectCamp);
  app.get('/api/admin/volunteers', b.adminGetVolunteers);
  app.delete('/api/admin/volunteers/:id', b.adminDeleteVolunteer);
  app.get('/api/debug/volunteers', b.adminDebugVolunteers);
  // Public debug endpoint to quickly inspect in-memory volunteers (dev only)
  app.get('/api/debug/memory-volunteers', b.debugMemoryVolunteersPublic);

  const m = await import("./routes/maps");
  app.get("/api/maps-key", m.getKey);

  return app;
}
