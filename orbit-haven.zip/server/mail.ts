// Initialize transporter with Gmail SMTP
let transporter: any = null;

export async function initMailer() {
  const email = process.env.GMAIL_EMAIL;
  const appPassword = process.env.GMAIL_APP_PASSWORD;

  if (!email || !appPassword) {
    // eslint-disable-next-line no-console
    console.warn('Gmail credentials not configured. Email delivery disabled.');
    return null;
  }

  try {
    // Dynamic import to avoid build-time issues
    const nodemailer = await import('nodemailer');
    transporter = nodemailer.default.createTransport({
      service: 'gmail',
      auth: {
        user: email,
        pass: appPassword.replace(/\s/g, ''), // Remove spaces from app password
      },
    });

    // eslint-disable-next-line no-console
    console.info('Gmail transporter initialized for:', email);
    return transporter;
  } catch (error: any) {
    // eslint-disable-next-line no-console
    console.error('Failed to initialize mail transporter:', error?.message);
    return null;
  }
}

export async function sendEmail(to: string, subject: string, html: string): Promise<boolean> {
  try {
    if (!transporter) {
      transporter = await initMailer();
      if (!transporter) {
        // eslint-disable-next-line no-console
        console.warn('Cannot send email: transporter not configured');
        return false;
      }
    }

    const email = process.env.GMAIL_EMAIL;
    if (!email) {
      // eslint-disable-next-line no-console
      console.warn('GMAIL_EMAIL not configured');
      return false;
    }

    const result = await transporter.sendMail({
      from: email,
      to,
      subject,
      html,
    });

    // eslint-disable-next-line no-console
    console.info('Email sent:', { to, subject, messageId: result.messageId });
    return true;
  } catch (error: any) {
    // eslint-disable-next-line no-console
    console.error('Failed to send email:', { to, error: error?.message });
    return false;
  }
}

export async function sendBulkEmails(recipients: string[], subject: string, html: string): Promise<{ sent: number; failed: number }> {
  let sent = 0;
  let failed = 0;

  for (const email of recipients) {
    const success = await sendEmail(email, subject, html);
    if (success) sent++;
    else failed++;
  }

  return { sent, failed };
}
